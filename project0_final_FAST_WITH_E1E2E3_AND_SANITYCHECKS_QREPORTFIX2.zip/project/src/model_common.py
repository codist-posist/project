from __future__ import annotations
from dataclasses import dataclass
from typing import Dict
import torch
from .config import ModelParams

@dataclass(frozen=True)
class State:
    Delta_prev: torch.Tensor
    logA: torch.Tensor
    loggtilde: torch.Tensor
    xi: torch.Tensor
    s: torch.Tensor
    vartheta_prev: torch.Tensor | None = None
    varrho_prev: torch.Tensor | None = None

def unpack_state(x: torch.Tensor, policy: str) -> State:
    if policy in ["taylor","mod_taylor","discretion"]:
        assert x.shape[-1] == 5
        return State(x[...,0], x[...,1], x[...,2], x[...,3], x[...,4].long())
    if policy == "commitment":
        assert x.shape[-1] == 7
        return State(x[...,0], x[...,1], x[...,2], x[...,3], x[...,4].long(), x[...,5], x[...,6])
    raise ValueError(policy)

def identities(params: ModelParams, st: State, out: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
    A = torch.exp(st.logA)
    gtilde = torch.exp(st.loggtilde)
    g = params.g_bar * gtilde
    eta = torch.where(st.s==0, torch.zeros_like(st.Delta_prev), torch.full_like(st.Delta_prev, params.eta_bar))
    one_plus_tau = 1.0 - params.tau_bar + st.xi + eta
    y = out["c"] + g
    h = y * out["Delta"] / A
    return {"A": A, "gtilde": gtilde, "g": g, "eta": eta, "one_plus_tau": one_plus_tau, "y": y, "h": h}

def shock_laws_of_motion(params: ModelParams, st: State, epsA: torch.Tensor, epsg: torch.Tensor, epstau: torch.Tensor, s_next: torch.Tensor):
    """Laws of motion for exogenous shocks.

    Supports both 1D shock draws (B,) and vectorized quadrature grids (B,Q,R).
    We broadcast state components along the last dimensions so they align with eps tensors.
    """
    # Regime-dependent volatility (Veronica robustness):
    # use current regime s_t to scale next-period shock std devs.
    # This keeps the DEQN equations intact and only changes the conditional distribution.
    s_cur = st.s.to(dtype=torch.float32)
    mA = 1.0 + (float(getattr(params, "sigma_A_bad_mult", 1.0)) - 1.0) * s_cur
    mg = 1.0 + (float(getattr(params, "sigma_g_bad_mult", 1.0)) - 1.0) * s_cur
    mt = 1.0 + (float(getattr(params, "sigma_tau_bad_mult", 1.0)) - 1.0) * s_cur

    # Effective sigmas (shape matches state broadcast below)
    sigma_A_eff = params.sigma_A * mA
    sigma_g_eff = params.sigma_g * mg
    sigma_tau_eff = params.sigma_tau * mt

    # Drift correction for log processes (A and g) to keep E[exp(log)] stable under different variances.
    driftA = (1.0 - params.rho_A) * (-(sigma_A_eff**2) / (2.0 * (1.0 - params.rho_A**2)))
    driftg = (1.0 - params.rho_g) * (-(sigma_g_eff**2) / (2.0 * (1.0 - params.rho_g**2)))

    if epsA.ndim == 3:
        B = st.logA.shape[0]
        logA = st.logA.view(B, 1, 1)
        logg = st.loggtilde.view(B, 1, 1)
        xi = st.xi.view(B, 1, 1)
        # broadcast effective sigmas and drifts
        sigma_A_eff = sigma_A_eff.view(B, 1, 1)
        sigma_g_eff = sigma_g_eff.view(B, 1, 1)
        sigma_tau_eff = sigma_tau_eff.view(B, 1, 1)
        driftA = driftA.view(B, 1, 1)
        driftg = driftg.view(B, 1, 1)
    else:
        logA = st.logA
        logg = st.loggtilde
        xi = st.xi

    logA_next = driftA + params.rho_A * logA + sigma_A_eff * epsA
    logg_next = driftg + params.rho_g * logg + sigma_g_eff * epsg
    xi_next = params.rho_tau * xi + sigma_tau_eff * epstau
    return logA_next, logg_next, xi_next, s_next.long()
