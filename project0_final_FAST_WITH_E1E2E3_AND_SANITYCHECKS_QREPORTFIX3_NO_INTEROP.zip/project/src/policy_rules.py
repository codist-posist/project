from __future__ import annotations
import torch
from .config import ModelParams

def i_taylor(params: ModelParams, pi: torch.Tensor) -> torch.Tensor:
    return (1.0 + params.pi_bar)/params.beta - 1.0 + params.psi*(pi - params.pi_bar)

def i_modified_taylor(params: ModelParams, pi: torch.Tensor, rbar_by_regime: torch.Tensor, s: torch.Tensor) -> torch.Tensor:
    rbar = rbar_by_regime[s]
    return rbar + params.psi*(pi - params.pi_bar)

def fisher_euler_term(params: ModelParams, i_t: torch.Tensor, pi_next: torch.Tensor, lam_next: torch.Tensor) -> torch.Tensor:
    return params.beta * ((1.0 + i_t)/(1.0 + pi_next)) * lam_next
