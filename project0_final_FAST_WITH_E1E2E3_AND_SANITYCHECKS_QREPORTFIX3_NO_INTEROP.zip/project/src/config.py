from __future__ import annotations
from dataclasses import dataclass
from typing import Literal, Tuple
import torch

PolicyName = Literal["taylor", "mod_taylor", "discretion", "commitment"]

@dataclass(frozen=True)
class ModelParams:
    # Table 1 (Galo–Nuno): key parameters
    beta: float = 0.9975
    gamma: float = 2.0
    omega: float = 1.0

    theta: float = 0.75
    eps: float = 7.0
    tau_bar: float = 1.0/7.0  # = 1/eps

    # Shock persistence
    rho_A: float = 0.99
    rho_tau: float = 0.90
    rho_g: float = 0.97

    # Shock volatilities
    sigma_A: float = 0.009
    sigma_tau: float = 0.0014
    sigma_g: float = 0.0052

    # --- Project1 / Veronica robustness: regime-dependent uncertainty ---
    # Multipliers applied to shock volatilities when s_t = 1 ("bad" regime).
    # Defaults are 1.0 (baseline replication).
    sigma_A_bad_mult: float = 1.0
    sigma_tau_bad_mult: float = 1.0
    sigma_g_bad_mult: float = 1.0

    # Levels / regimes
    g_bar: float = 0.20
    eta_bar: float = 1.0/7.0  # = 1/eps

    # Markov transition probabilities (normal->bad, bad->normal)
    p12: float = 1.0/48.0
    p21: float = 1.0/24.0

    # Taylor-rule objects (paper uses pi_bar = 0)
    pi_bar: float = 0.0
    psi: float = 2.0

    device: str = "cpu"
    dtype: torch.dtype = torch.float32

    def to_torch(self) -> "ModelParams":
        torch.zeros(1, device=self.device, dtype=self.dtype)
        return self

    @property
    def M(self) -> float:
        return self.eps/(self.eps-1.0)

    @property
    def P(self) -> torch.Tensor:
        # P[s_next, s]
        p11 = 1.0 - self.p12
        p22 = 1.0 - self.p21
        return torch.tensor([[p11, self.p21],
                             [self.p12, p22]], device=self.device, dtype=self.dtype)

@dataclass(frozen=True)
class TrainConfig:
    seed: int = 123
    batch_size: int = 512
    steps: int = 20000
    fine_tune_steps: int = 5000
    lr: float = 1e-5
    fine_tune_lr: float = 1e-6
    grad_clip: float = 1.0

    hidden_layers: Tuple[int, int] = (512, 512)
    activation: str = "selu"

    c_floor: float = 1e-8
    delta_floor: float = 1e-10
    pstar_floor: float = 1e-10

    artifacts_root: str = "../artifacts"

    # Run directory for this training run. If provided, training artifacts can be
    # saved during training (e.g., best checkpoint by validation loss).
    run_dir: str | None = None
    save_best: bool = True
    best_weights_name: str = "weights_best.pt"

    # ---- Performance / training data pipeline (DEQN-compatible) ----
    # Keep a replay buffer of recently simulated states and refresh it occasionally
    # under no_grad. This preserves the DEQN objective E[G(x,N(x))^2] while
    # avoiding extremely expensive per-step resimulation.
    replay_buffer_size: int = 120_000
    replay_refresh_every: int = 50          # refresh buffer every N gradient steps
    replay_refresh_steps: int = 80          # number of state transitions per refresh
    replay_init_fill_steps: int = 200       # initial steps to populate the buffer
    replay_refresh_frac: float = 0.25       # fraction of population to reinit on refresh

    # Default GH order for training (validation can override)
    gh_n_train: int = 3

    # ---- CPU / performance knobs (do not change equations) ----
    # If None, PyTorch defaults are used.
    cpu_num_threads: int | None = None
    cpu_num_interop_threads: int | None = None
    # PyTorch 2.x: affects internal matmul kernels; safe to set.
    matmul_precision: str = "high"  # "highest"/"high"/"medium"

    # ---- Profiling / timing ----
    # Lightweight timers print averages every log_every steps.
    log_every: int = 50
    enable_timers: bool = True
    # Optional PyTorch profiler trace (Chrome).
    profile: bool = False
    profile_dir: str = "../artifacts/profiles"
    profile_steps: int = 200  # number of training steps to record


    # ---- Validation / early stopping (does not change equations) ----
    # Validation is computed on a fixed batch of states (sampled from replay buffer)
    # to monitor generalization and prevent wasting time.
    val_size: int = 4096
    val_every: int = 500

    # If True, stop training when validation loss fails to improve by min_delta
    # for patience steps.
    early_stopping: bool = False
    patience: int = 5000
    min_delta: float = 1e-5

    # Optional: reduce LR on plateau (useful when early_stopping=False).
    reduce_lr_on_plateau: bool = False
    plateau_patience: int = 5000
    lr_reduce_factor: float = 0.5
    min_lr: float = 1e-7

def set_seeds(seed: int) -> None:
    import numpy as np, random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
