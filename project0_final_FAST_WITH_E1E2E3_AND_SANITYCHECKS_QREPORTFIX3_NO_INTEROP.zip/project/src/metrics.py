from __future__ import annotations
from typing import Dict
import numpy as np

def moments(x: np.ndarray) -> Dict[str, float]:
    x = np.asarray(x)
    return {"mean": float(np.mean(x)), "std": float(np.std(x))}

def summarize_series(series: Dict[str, np.ndarray]) -> Dict[str, Dict[str, float]]:
    return {k: moments(v) for k, v in series.items()}
