
from __future__ import annotations

import os
from typing import Dict, Any, Optional, List, Tuple

import numpy as np
import pandas as pd
import torch

from .config import ModelParams, PolicyName
from .io_utils import load_selected_run, find_latest_run_dir, load_torch, load_json
from .steady_states import solve_flexprice_sss, solve_efficient_sss, solve_commitment_sss_from_policy
from .sss_from_policy import discretion_sss_from_policy, simple_policy_sss_from_policy
from .deqn import PolicyNetwork, implied_nominal_rate_from_euler
from .deqn import Trainer
from .config import TrainConfig
from .metrics import output_gap_from_consumption


def _skew(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=np.float64)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return float("nan")
    mu = float(np.mean(x))
    sd = float(np.std(x))
    if sd == 0.0:
        return 0.0
    z = (x - mu) / sd
    return float(np.mean(z**3))


def _moments_with_skew(x: np.ndarray) -> Dict[str, float]:
    x = np.asarray(x, dtype=np.float64)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return {"mean": float("nan"), "std": float("nan"), "skew": float("nan")}
    return {"mean": float(np.mean(x)), "std": float(np.std(x)), "skew": _skew(x)}


def _split_by_regime(x: np.ndarray, s: np.ndarray, regime: int) -> np.ndarray:
    s = np.asarray(s).astype(int)
    x = np.asarray(x)
    return x[s == int(regime)]


def _annualize_pct(x: np.ndarray | float) -> np.ndarray | float:
    # model units: quarterly net (e.g., pi=0.007); table units: annualized percent
    return 400.0 * x


def _load_run_dir(artifacts_root: str, policy: str, *, use_selected: bool = True) -> str:
    rd: Optional[str] = None
    if use_selected:
        rd = load_selected_run(artifacts_root, policy)
    if rd is None:
        rd = find_latest_run_dir(artifacts_root, policy)
    if rd is None:
        raise FileNotFoundError(f"No run directory found for policy='{policy}' under {artifacts_root}")
    return rd


def _load_net_from_run(run_dir: str, params: ModelParams, policy: PolicyName) -> PolicyNetwork:
    w_path = os.path.join(run_dir, "weights.pt")
    if not os.path.exists(w_path):
        # back-compat
        w_path = os.path.join(run_dir, "weights_best.pt")
    if not os.path.exists(w_path):
        raise FileNotFoundError(f"Missing weights in {run_dir} (expected weights.pt or weights_best.pt)")
    net = PolicyNetwork(policy=policy, params=params).to(device=params.device, dtype=params.dtype)
    state = load_torch(w_path, map_location=params.device)
    net.load_state_dict(state)
    net.eval()
    return net


def _load_sim_paths(run_dir: str) -> Dict[str, np.ndarray]:
    p = os.path.join(run_dir, "sim_paths.npz")
    if not os.path.exists(p):
        raise FileNotFoundError(f"Missing sim_paths.npz in {run_dir}. Re-run training notebook to save it.")
    data = np.load(p)
    return {k: data[k] for k in data.files}


def _compute_real_rate_series(sim: Dict[str, np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
    """
    Real rate per period computed from realized next inflation:
        r_t = (1+i_t)/(1+pi_{t+1}) - 1
    Returned arrays aligned with s_t (length T-1):
        r, s_aligned
    """
    i = np.asarray(sim["i"])
    pi = np.asarray(sim["pi"])
    s = np.asarray(sim["s"])
    # align to t where pi_{t+1} exists
    r = (1.0 + i[:-1]) / (1.0 + pi[1:]) - 1.0
    s_aligned = s[:-1]
    return r, s_aligned


def _policy_sss_for_policy(
    params: ModelParams,
    policy: PolicyName,
    net: PolicyNetwork,
    regime: int,
) -> Dict[str, float]:
    if policy == "commitment":
        return solve_commitment_sss_from_policy(params, net).by_regime[int(regime)]
    if policy == "discretion":
        return discretion_sss_from_policy(params, net, regime=int(regime))
    # taylor / mod_taylor:
    return simple_policy_sss_from_policy(params, net, policy=policy, regime=int(regime))


def _implied_i_at_sss(
    params: ModelParams,
    policy: PolicyName,
    net: PolicyNetwork,
    sss: Dict[str, float],
    *,
    regime: int,
    rbar_by_regime: torch.Tensor | None,
) -> float:
    # build a single-state tensor consistent with model_common.State order
    dev, dt = params.device, params.dtype
    if policy == "commitment":
        x = torch.tensor(
            [sss["Delta"], sss["logA"], sss["loggtilde"], sss["xi"], float(regime), sss["vartheta_prev"], sss["varrho_prev"]],
            device=dev, dtype=dt
        ).view(1, -1)
    else:
        x = torch.tensor([sss["Delta"], sss["logA"], sss["loggtilde"], sss["xi"], float(regime)], device=dev, dtype=dt).view(1, -1)

    out = {
        "c": torch.tensor([sss["c"]], device=dev, dtype=dt),
        "pi": torch.tensor([sss["pi"]], device=dev, dtype=dt),
        "pstar": torch.tensor([sss["pstar"]], device=dev, dtype=dt),
        "lam": torch.tensor([sss["lam"]], device=dev, dtype=dt),
        "w": torch.tensor([sss["w"]], device=dev, dtype=dt),
        "XiN": torch.tensor([sss["XiN"]], device=dev, dtype=dt),
        "XiD": torch.tensor([sss["XiD"]], device=dev, dtype=dt),
        "Delta": torch.tensor([sss["Delta"]], device=dev, dtype=dt),
    }
    # minimal trainer (no training)
    cfg_sim = TrainConfig.dev(seed=0) if params.device == "cpu" else TrainConfig.full(seed=0)
    trainer = Trainer(params=params, cfg=cfg_sim, policy=policy, net=net, gh_n=7, rbar_by_regime=rbar_by_regime)
    i_t = implied_nominal_rate_from_euler(params, policy, x, out, 7, trainer)
    return float(i_t.item())


def build_table2(
    artifacts_root: str,
    *,
    device: str = "cpu",
    dtype: torch.dtype = torch.float32,
    use_selected: bool = True,
    include_rules: bool = True,
) -> pd.DataFrame:
    """
    Build a Table-2-like summary after trainings.

    Policies included:
      - flex prices
      - commitment
      - discretion
      - (optional) taylor, mod_taylor

    Uses:
      - SSS computed AFTER training as fixed points of the trained policies.
      - Ergodic moments from saved sim_paths.npz in each run directory.
    """
    params = ModelParams(device=device, dtype=dtype)
    # flex SSS
    flex = solve_flexprice_sss(params)

    # efficient c_hat: per paper definition, use normal-times efficient allocation
    eff_ss = solve_efficient_sss(params)
    c_hat = float(eff_ss["c_hat"])

        # rbar_by_regime (needed for mod_taylor): use flex-price natural rates if nothing saved
    rbar_by_regime = torch.tensor(
        [flex.by_regime[0]["r_star"], flex.by_regime[1]["r_star"]],
        device=params.device,
        dtype=params.dtype,
    )
    # If a previously-saved file exists, allow it to override (back-compat)
    rbar_path = os.path.join(artifacts_root, "flex", "sss.json")
    if os.path.exists(rbar_path):
        try:
            js = load_json(rbar_path)
            if "rbar_by_regime" in js:
                rbar_by_regime = torch.tensor(js["rbar_by_regime"], device=params.device, dtype=params.dtype)
        except Exception:
            pass

    policies: List[Tuple[str, Optional[str]]] = [
        ("flex", None),
        ("commitment", "commitment"),
        ("discretion", "discretion"),
    ]
    if include_rules:
        policies += [("taylor", "taylor"), ("mod_taylor", "mod_taylor")]

    rows: List[Dict[str, Any]] = []

    def add_block(label: str, policy_key: str, regime: int, sss: Dict[str, float], sim: Optional[Dict[str, np.ndarray]]):
        # SSS statistics
        pi_ss = float(sss["pi"])
        # output gap SSS: log(c) - log(c_hat)
        x_ss = float(np.log(float(sss["c"])) - np.log(c_hat))
        # nominal/real in SSS
        if policy_key == "flex":
            i_ss = float(flex.by_regime[regime]["r_star"])  # pi=0 so nominal=real
        else:
            net = nets[policy_key]
            i_ss = _implied_i_at_sss(params, policy_key, net, sss, regime=regime, rbar_by_regime=rbar_by_regime if policy_key=="mod_taylor" else None)
        r_ss = (1.0 + i_ss) / (1.0 + pi_ss) - 1.0

        # moments from sim
        if sim is None:
            pi_m = {"mean": np.nan, "std": np.nan, "skew": np.nan}
            x_m = {"mean": np.nan, "std": np.nan, "skew": np.nan}
            r_m = {"mean": np.nan, "std": np.nan, "skew": np.nan}
            i_m = {"mean": np.nan, "std": np.nan, "skew": np.nan}
        else:
            s = sim["s"]
            # inflation
            pi_series = _split_by_regime(sim["pi"], s, regime)
            pi_m = _moments_with_skew(pi_series)
            # output gap
            x_all = output_gap_from_consumption(sim, c_hat, params=params)
            x_series = _split_by_regime(x_all, s, regime)
            x_m = _moments_with_skew(x_series)
            # nominal
            i_series = _split_by_regime(sim["i"], s, regime)
            i_m = _moments_with_skew(i_series)
            # real (aligned to t with pi_{t+1})
            r_all, s_al = _compute_real_rate_series(sim)
            r_series = _split_by_regime(r_all, s_al, regime)
            r_m = _moments_with_skew(r_series)

        rows.append({
            "policy": label,
            "regime": "normal" if regime == 0 else "bad",
            # Inflation
            "pi_sss_pct": _annualize_pct(pi_ss),
            "pi_mean_pct": _annualize_pct(pi_m["mean"]),
            "pi_std_pct": _annualize_pct(pi_m["std"]),
            "pi_skew": pi_m["skew"],
            # Output gap
            "x_sss_pct": 100.0 * x_ss,
            "x_mean_pct": 100.0 * x_m["mean"],
            "x_std_pct": 100.0 * x_m["std"],
            "x_skew": x_m["skew"],
            # Real rate
            "r_sss_pct": _annualize_pct(r_ss),
            "r_mean_pct": _annualize_pct(r_m["mean"]),
            "r_std_pct": _annualize_pct(r_m["std"]),
            "r_skew": r_m["skew"],
            # Nominal rate
            "i_sss_pct": _annualize_pct(i_ss),
            "i_mean_pct": _annualize_pct(i_m["mean"]),
            "i_std_pct": _annualize_pct(i_m["std"]),
            "i_skew": i_m["skew"],
        })

    nets: Dict[str, PolicyNetwork] = {}
    sims: Dict[str, Dict[str, np.ndarray]] = {}

    # load nets + sims for trained policies
    for label, pkey in policies:
        if pkey is None:
            continue
        run_dir = _load_run_dir(artifacts_root, pkey, use_selected=use_selected)
        nets[pkey] = _load_net_from_run(run_dir, params, pkey)
        sims[pkey] = _load_sim_paths(run_dir)

    # flex block
    for s in [0, 1]:
        add_block("flex", "flex", s, flex.by_regime[s], None if "flex" not in sims else sims["flex"])  # flex sim optional
    # others
    for label, pkey in policies:
        if pkey is None:
            continue
        for s in [0, 1]:
            sss = _policy_sss_for_policy(params, pkey, nets[pkey], s)
            # add required fields for commitment (vartheta_prev,varrho_prev) if missing
            if pkey == "commitment":
                # solve_commitment_sss_from_policy returns them already
                pass
            sim = sims.get(pkey)
            add_block(label, pkey, s, sss, sim)

    df = pd.DataFrame(rows)
    # Order like paper: by policy then regime
    pol_order = ["flex", "commitment", "discretion", "taylor", "mod_taylor"]
    df["policy"] = pd.Categorical(df["policy"], categories=pol_order, ordered=True)
    df["regime"] = pd.Categorical(df["regime"], categories=["normal", "bad"], ordered=True)
    df = df.sort_values(["policy", "regime"]).reset_index(drop=True)
    return df


def save_table2_csv(df: pd.DataFrame, artifacts_root: str, *, filename: str = "table2_reproduced.csv") -> str:
    out_path = os.path.join(artifacts_root, filename)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    df.to_csv(out_path, index=False)
    return out_path
