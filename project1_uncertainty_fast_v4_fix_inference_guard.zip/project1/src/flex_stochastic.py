"""Stochastic flex-price allocation and uncertainty-sensitive natural rate r*_s.

This module is used for Project1 (Veronica critique): when volatility is regime-dependent,
the natural rate must be computed from a *stochastic* flex-price equilibrium so that
precautionary saving can affect

    E[(c_{t+1}/c_t)^(-gamma) | s_t=s].

Design:
- Uses the SAME Markov chain and AR(1) shock laws as the main model.
- Solves flex allocation period-by-period from identities/FOCs (no network, no Calvo).
- Produces r*_s estimates by conditioning on the current regime.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np
import torch

from .config import ModelParams


@dataclass
class FlexStochResult:
    rstar_by_regime: np.ndarray  # shape (2,)
    c: np.ndarray                # shape (T,)
    s: np.ndarray                # shape (T,)


def _draw_markov_next(P: torch.Tensor, s: torch.Tensor, u: torch.Tensor) -> torch.Tensor:
    """Draw s_{t+1} given current s_t and uniforms u. P is oriented P[next, current]."""
    p0 = P[0, s]
    return torch.where(u < p0, torch.zeros_like(s), torch.ones_like(s))


@torch.inference_mode()
def simulate_flex_and_rstar(
    params: ModelParams,
    *,
    T: int = 50_000,
    burn: int = 5_000,
    seed: int = 0,
) -> FlexStochResult:
    """Simulate flex-price allocation and estimate r*_s from stochastic MRS.

    Notes:
    - We only need (c_t, s_t) to compute MRS moments.
    - The flex allocation is solved from:
        mc = 1/M
        w = A / (M (1+tau))
        h^omega = w * c^{-gamma}
        c + g = A h
      with tau_t = -tau_bar + xi_t + eta_t (and 1+tau = 1 - tau_bar + xi + eta).
    """
    p = params.to_torch()
    dev, dt = p.device, p.dtype
    torch.manual_seed(int(seed))
    np.random.seed(int(seed))

    # states
    logA = torch.zeros((), device=dev, dtype=dt)
    logg = torch.zeros((), device=dev, dtype=dt)
    xi = torch.zeros((), device=dev, dtype=dt)
    s = torch.zeros((), device=dev, dtype=torch.long)

    c_path = torch.empty((T,), device=dev, dtype=dt)
    s_path = torch.empty((T,), device=dev, dtype=torch.long)

    P = p.P
    M = float(p.M)
    g_bar = float(p.g_bar)
    omega = float(p.omega)
    gamma = float(p.gamma)

    for t in range(T):
        # compute levels
        A = torch.exp(logA)
        gtilde = torch.exp(logg)
        g = g_bar * gtilde
        eta = torch.where(s == int(p.bad_state), torch.tensor(float(p.eta_bar), device=dev, dtype=dt), torch.tensor(0.0, device=dev, dtype=dt))
        one_plus_tau = 1.0 - float(p.tau_bar) + xi + eta

        # flex FOCs/identities
        w = A / (M * one_plus_tau)

        # solve for c from (c+g)^omega = w * c^{-gamma}
        # We'll do a few Newton steps (very cheap in scalar form).
        c = torch.tensor(1.0, device=dev, dtype=dt)
        for _ in range(40):
            f = (c + g).pow(omega) - w * c.pow(-gamma)
            df = omega * (c + g).pow(omega - 1.0) + gamma * w * c.pow(-gamma - 1.0)
            step = f / df
            c_new = torch.clamp(c - step, min=1e-10)
            if torch.max(torch.abs(c_new - c)).item() < 1e-12:
                c = c_new
                break
            c = c_new

        c_path[t] = c
        s_path[t] = s

        # evolve shocks
        epsA = torch.randn((), device=dev, dtype=dt)
        epsg = torch.randn((), device=dev, dtype=dt)
        epst = torch.randn((), device=dev, dtype=dt)
        u = torch.rand((), device=dev, dtype=dt)
        s_next = _draw_markov_next(P, s.view(1), u.view(1))[0]

        # effective sigmas (same logic as model_common.shock_laws_of_motion)
        bad = (s == int(p.bad_state))
        sigA = float(p.sigma_A) * (float(p.sigma_A_bad_mult) if bool(bad) else 1.0)
        sigg = float(p.sigma_g) * (float(p.sigma_g_bad_mult) if bool(bad) else 1.0)
        sigt = float(p.sigma_tau) * (float(p.sigma_tau_bad_mult) if bool(bad) else 1.0)

        driftA = (1.0 - float(p.rho_A)) * (-(sigA ** 2) / (2.0 * (1.0 - float(p.rho_A) ** 2)))
        driftg = (1.0 - float(p.rho_g)) * (-(sigg ** 2) / (2.0 * (1.0 - float(p.rho_g) ** 2)))

        logA = torch.tensor(driftA, device=dev, dtype=dt) + float(p.rho_A) * logA + torch.tensor(sigA, device=dev, dtype=dt) * epsA
        logg = torch.tensor(driftg, device=dev, dtype=dt) + float(p.rho_g) * logg + torch.tensor(sigg, device=dev, dtype=dt) * epsg
        xi = float(p.rho_tau) * xi + torch.tensor(sigt, device=dev, dtype=dt) * epst
        s = s_next

    # compute r*_s from MRS, conditioning on s_t
    c_np = c_path.detach().cpu().numpy()
    s_np = s_path.detach().cpu().numpy().astype(int)

    # drop burn
    c_np = c_np[int(burn):]
    s_np = s_np[int(burn):]

    # MRS sample: (c_{t+1}/c_t)^(-gamma)
    mrs = (c_np[1:] / c_np[:-1]) ** (-float(params.gamma))
    s_aligned = s_np[:-1]

    rstar = np.zeros((2,), dtype=np.float64)
    for regime in (0, 1):
        mask = (s_aligned == regime)
        Em = float(np.mean(mrs[mask])) if np.any(mask) else np.nan
        rstar[regime] = (1.0 / (float(params.beta) * Em)) - 1.0

    return FlexStochResult(rstar_by_regime=rstar, c=c_np, s=s_np)
