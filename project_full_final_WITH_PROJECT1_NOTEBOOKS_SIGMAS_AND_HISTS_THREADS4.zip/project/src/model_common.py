from __future__ import annotations
from dataclasses import dataclass
from typing import Dict
import torch
from .config import ModelParams

@dataclass(frozen=True)
class State:
    Delta_prev: torch.Tensor
    logA: torch.Tensor
    loggtilde: torch.Tensor
    xi: torch.Tensor
    s: torch.Tensor
    vartheta_prev: torch.Tensor | None = None
    varrho_prev: torch.Tensor | None = None

def unpack_state(x: torch.Tensor, policy: str) -> State:
    if policy in ["taylor","mod_taylor","discretion"]:
        assert x.shape[-1] == 5
        return State(x[...,0], x[...,1], x[...,2], x[...,3], x[...,4].long())
    if policy == "commitment":
        assert x.shape[-1] == 7
        return State(x[...,0], x[...,1], x[...,2], x[...,3], x[...,4].long(), x[...,5], x[...,6])
    raise ValueError(policy)

def identities(params: ModelParams, st: State, out: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
    A = torch.exp(st.logA)
    gtilde = torch.exp(st.loggtilde)
    g = params.g_bar * gtilde
    eta = torch.where(st.s==0, torch.zeros_like(st.Delta_prev), torch.full_like(st.Delta_prev, params.eta_bar))
    one_plus_tau = 1.0 - params.tau_bar + st.xi + eta
    y = out["c"] + g
    h = y * out["Delta"] / A
    return {"A": A, "gtilde": gtilde, "g": g, "eta": eta, "one_plus_tau": one_plus_tau, "y": y, "h": h}

def shock_laws_of_motion(params: ModelParams, st: State, epsA: torch.Tensor, epsg: torch.Tensor, epstau: torch.Tensor, s_next: torch.Tensor):
    """Laws of motion for exogenous shocks.

    Supports both 1D shock draws (B,) and vectorized quadrature grids (B,Q,R).
    We broadcast state components along the last dimensions so they align with eps tensors.
    """
    driftA_base = (1.0 - params.rho_A) * (-(params.sigma_A**2) / (2.0 * (1.0 - params.rho_A**2)))
    driftg_base = (1.0 - params.rho_g) * (-(params.sigma_g**2) / (2.0 * (1.0 - params.rho_g**2)))

    if epsA.ndim == 3:
        B = st.logA.shape[0]
        logA = st.logA.view(B, 1, 1)
        logg = st.loggtilde.view(B, 1, 1)
        xi = st.xi.view(B, 1, 1)
        s = st.s.view(B, 1, 1).to(logA.dtype)
    else:
        logA = st.logA
        logg = st.loggtilde
        xi = st.xi
        s = st.s.to(logA.dtype)

    # Regime-dependent uncertainty (Veronica Guerrieri critique extension):
    # in bad regime (s=1), sigma is multiplied by sigma_*_bad_mult.
    sigmaA_eff = params.sigma_A * (1.0 + (params.sigma_A_bad_mult - 1.0) * s)
    sigmag_eff = params.sigma_g * (1.0 + (params.sigma_g_bad_mult - 1.0) * s)
    sigmatau_eff = params.sigma_tau * (1.0 + (params.sigma_tau_bad_mult - 1.0) * s)

    # Mean-adjustment drift for log processes uses the (state-dependent) variance to keep E[A] stable.
    driftA = (1.0 - params.rho_A) * (-(sigmaA_eff**2) / (2.0 * (1.0 - params.rho_A**2)))
    driftg = (1.0 - params.rho_g) * (-(sigmag_eff**2) / (2.0 * (1.0 - params.rho_g**2)))

    logA_next = driftA + params.rho_A * logA + sigmaA_eff * epsA
    logg_next = driftg + params.rho_g * logg + sigmag_eff * epsg
    xi_next = params.rho_tau * xi + sigmatau_eff * epstau
    return logA_next, logg_next, xi_next, s_next.long()

