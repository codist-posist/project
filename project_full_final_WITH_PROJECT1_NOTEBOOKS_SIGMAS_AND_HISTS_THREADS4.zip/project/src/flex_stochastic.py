
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np
import torch

from .config import ModelParams
from .model_common import shock_laws_of_motion, unpack_state, State

def _solve_flex_c(params: ModelParams, A: torch.Tensor, g: torch.Tensor, tau: torch.Tensor, *, max_iter: int = 60) -> torch.Tensor:
    """
    Solve flex-price allocation for consumption c given (A,g,tau).
    Equations:
        mc = 1/M  => w = A / (M*(1+tau))
        intratemporal: h^omega = w * c^{-gamma}
        resource: c + g = A*h
    Substitute h = (c+g)/A into intratemporal and solve for c.
    """
    M = params.M
    omega = params.omega
    gamma = params.gamma

    # Initial guess: c ≈ (1-gbar) * A * h_ss ~ 1
    c = torch.clamp(A - g, min=1e-8)

    w = A / (M * (1.0 + tau))

    for _ in range(max_iter):
        h = (c + g) / A
        # f(c)= h^omega - w*c^{-gamma}
        f = h.pow(omega) - w * c.pow(-gamma)
        # df/dc = omega*h^{omega-1}*(1/A) + w*gamma*c^{-gamma-1}
        df = omega * h.pow(omega - 1.0) * (1.0 / A) + w * gamma * c.pow(-gamma - 1.0)
        step = f / df
        c_new = torch.clamp(c - step, min=1e-10)
        # simple damping for stability
        c = 0.7 * c + 0.3 * c_new
    return c


@torch.no_grad()
def simulate_flex_and_rstar(
    params: ModelParams,
    T: int = 200_000,
    burn_in: int = 20_000,
    seed: int = 123,
    sigma_bad_mult: float = 1.0,
    *,
    B: int = 1,
) -> Dict[str, float]:
    """
    Simulate stochastic flex-price economy and estimate r*_s by regime:
        1+r*_s = 1 / (beta * E[(c_{t+1}/c_t)^(-gamma) | s_t=s])
    Uses the project's shock laws of motion (incl. Markov switching) with regime-dependent
    volatility via params.sigma_*_bad_mult.

    Returns dict with rstar_normal, rstar_bad, delta_rstar.
    """
    assert B == 1, "For r* estimation use B=1 to avoid mixing regimes across units."
    # make a local copy with adjusted multipliers
    p = ModelParams(**{**params.__dict__,
                      "sigma_A_bad_mult": sigma_bad_mult,
                      "sigma_g_bad_mult": sigma_bad_mult,
                      "sigma_tau_bad_mult": sigma_bad_mult}).to_torch()

    torch.manual_seed(seed)
    dev, dt = p.device, p.dtype

    # initial state near 0 with random regime
    Delta_prev = torch.ones((B,), device=dev, dtype=dt)
    logA = torch.zeros((B,), device=dev, dtype=dt)
    loggtilde = torch.zeros((B,), device=dev, dtype=dt)
    xi = torch.zeros((B,), device=dev, dtype=dt)
    s = torch.randint(0, 2, (B,), device=dev, dtype=torch.long)
    x = torch.stack([Delta_prev, logA, loggtilde, xi, s.to(dt)], dim=-1)

    # store consumption to compute MRS
    c_hist = []
    s_hist = []

    for t in range(T):
        st = unpack_state(x, policy="taylor")
        A = torch.exp(st.logA)
        g = p.g_bar * torch.exp(st.loggtilde)
        tau = (1.0 - p.tau_bar) + st.xi + p.eta_bar  # consistent with identities usage

        c = _solve_flex_c(p, A, g, tau)
        c_hist.append(c.item())
        s_hist.append(int(st.s.item()))

        # advance state: draw shocks
        epsA = torch.randn((B,), device=dev, dtype=dt)
        epsg = torch.randn((B,), device=dev, dtype=dt)
        epst = torch.randn((B,), device=dev, dtype=dt)
                # Markov transition draw
        u = torch.rand((B,), device=dev, dtype=dt)
        p0 = p.P[0, st.s]
        s_next = torch.where(u < p0, torch.zeros_like(st.s), torch.ones_like(st.s))
        logA_next, logg_next, xi_next, s_next = shock_laws_of_motion(p, st, epsA, epsg, epst, s_next)
        # Delta_prev is irrelevant in flex; keep 1
        x = torch.stack([Delta_prev, logA_next, logg_next, xi_next, s_next.to(dt)], dim=-1)

    c_arr = np.asarray(c_hist)
    s_arr = np.asarray(s_hist, dtype=np.int64)
    # compute MRS ratio
    g_c = (c_arr[1:] / c_arr[:-1]) ** (-p.gamma)
    s_t = s_arr[:-1]

    mask0 = s_t == 0
    mask1 = s_t == 1
    # avoid empty
    m0 = g_c[mask0].mean() if mask0.any() else np.nan
    m1 = g_c[mask1].mean() if mask1.any() else np.nan

    r0 = 1.0 / (p.beta * m0) - 1.0
    r1 = 1.0 / (p.beta * m1) - 1.0
    return {"rstar_normal": float(r0), "rstar_bad": float(r1), "delta_rstar": float(r1 - r0)}
