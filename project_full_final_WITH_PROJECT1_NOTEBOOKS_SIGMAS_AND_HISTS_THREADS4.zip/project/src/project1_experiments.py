
from __future__ import annotations
from typing import Dict
import numpy as np
import torch

from .config import ModelParams, TrainConfig, PolicyName
from .deqn import PolicyNetwork, Trainer
from .model_common import unpack_state, shock_laws_of_motion, identities
from .policy_rules import i_taylor, i_modified_taylor

@torch.no_grad()
def simulate_paths_crn(
    params: ModelParams,
    policy: PolicyName,
    net: PolicyNetwork,
    T: int,
    burn_in: int,
    x0: torch.Tensor,
    shocks: Dict[str, np.ndarray],
    rbar_by_regime: torch.Tensor | None = None,
    gh_n: int = 7,
):
    """
    Forward simulation using COMMON RANDOM NUMBERS:
      - epsA, epsg, epst: standard normal shocks of shape (T,B)
      - u: uniform(0,1) draws for Markov transition of shape (T,B)

    This mirrors src.deqn.simulate_paths but replaces RNG draws with provided arrays.
    Intended for apple-to-apple overlays when changing sigma_bad_mult.

    Returns the same store dict as simulate_paths, but with arrays of length (T-burn_in, B).
    """
    dev, dt = params.device, params.dtype
    net.eval()
    B = x0.shape[0]
    x = x0.to(device=dev, dtype=dt)

    trainer = Trainer(params=params, cfg=TrainConfig(seed=0), policy=policy, net=net, gh_n=gh_n, rbar_by_regime=rbar_by_regime)

    keep = T - burn_in
    store = {k: np.zeros((keep, B)) for k in ["c","pi","pstar","Delta","y","h","g","tau","i"]}
    store["s"] = np.zeros((keep, B), dtype=np.int64)

    for t in range(T):
        out = trainer._policy_outputs(x)
        st = unpack_state(x, policy)
        ids = identities(params, st, out)

        if policy == "taylor":
            i_t = i_taylor(params, out["pi"])
        elif policy == "mod_taylor":
            assert rbar_by_regime is not None
            i_t = i_modified_taylor(params, out["pi"], rbar_by_regime, st.s)
        else:
            raise NotImplementedError("simulate_paths_crn currently supports only taylor/mod_taylor for overlays.")

        if t >= burn_in:
            j = t - burn_in
            store["c"][j] = out["c"].cpu().numpy()
            store["pi"][j] = out["pi"].cpu().numpy()
            store["pstar"][j] = out["pstar"].cpu().numpy()
            store["Delta"][j] = out["Delta"].cpu().numpy()
            store["y"][j] = ids["y"].cpu().numpy()
            store["h"][j] = ids["h"].cpu().numpy()
            store["g"][j] = ids["g"].cpu().numpy()
            store["tau"][j] = ids["tau"].cpu().numpy()
            store["s"][j] = st.s.cpu().numpy()
            store["i"][j] = i_t.cpu().numpy()

        # advance exogenous state using provided shocks
        epsA = torch.tensor(shocks["epsA"][t], device=dev, dtype=dt)
        epsg = torch.tensor(shocks["epsg"][t], device=dev, dtype=dt)
        epst = torch.tensor(shocks["epst"][t], device=dev, dtype=dt)
        u = torch.tensor(shocks["u"][t], device=dev, dtype=dt)

        P = params.P
        p0 = P[0, st.s]
        s_next = torch.where(u < p0, torch.zeros_like(st.s), torch.ones_like(st.s))

        logA_n, logg_n, xi_n, s_n = shock_laws_of_motion(params, st, epsA, epsg, epst, s_next)

        if policy in ["taylor","mod_taylor"]:
            x = torch.stack([ids["Delta"], logA_n, logg_n, xi_n, s_n.to(dt)], dim=-1)
        else:
            raise NotImplementedError

    return store
