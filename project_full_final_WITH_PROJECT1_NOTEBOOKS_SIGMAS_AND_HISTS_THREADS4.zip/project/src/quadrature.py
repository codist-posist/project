from __future__ import annotations
from dataclasses import dataclass
import torch

@dataclass(frozen=True)
class GHQuadrature:
    nodes: torch.Tensor
    weights: torch.Tensor

def gauss_hermite(n: int, device: str, dtype: torch.dtype) -> GHQuadrature:
    import numpy as np
    from numpy.polynomial.hermite import hermgauss
    x, w = hermgauss(n)
    nodes = torch.tensor((2.0**0.5) * x, device=device, dtype=dtype)
    weights = torch.tensor(w / (np.pi**0.5), device=device, dtype=dtype)
    return GHQuadrature(nodes=nodes, weights=weights)
