from __future__ import annotations
import torch

def simulate_markov(P: torch.Tensor, s0: torch.Tensor, T: int) -> torch.Tensor:
    assert P.shape == (2,2)
    B = s0.shape[0]
    s = torch.empty((T,B), dtype=torch.long, device=s0.device)
    s[0] = s0
    for t in range(1,T):
        cur = s[t-1]
        u = torch.rand(B, device=s0.device)
        p0 = P[0, cur]
        s[t] = torch.where(u < p0, torch.zeros_like(cur), torch.ones_like(cur))
    return s
