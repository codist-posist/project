from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional
import time

import numpy as np
import torch
import torch.nn as nn



class ReplayView:
    """Lightweight view over the training replay buffer (for diagnostics).
    Stores a reference to the underlying tensor and a callable returning the current filled size.
    """
    def __init__(self, X_buf: torch.Tensor, get_filled):
        self.X_buf = X_buf
        self._get_filled = get_filled

    def sample(self, n: int) -> torch.Tensor:
        filled = int(self._get_filled())
        if filled <= 0:
            raise RuntimeError("Replay buffer is empty; training likely did not run long enough to fill it.")
        idx = torch.randint(0, filled, (n,), device=self.X_buf.device)
        return self.X_buf[idx]
import torch.optim as optim
from tqdm.auto import trange

from .config import ModelParams, TrainConfig, set_seeds, PolicyName
from .quadrature import gauss_hermite
from .model_common import unpack_state, shock_laws_of_motion, identities
from .transforms import decode_outputs
from .policy_rules import i_taylor, i_modified_taylor, fisher_euler_term
from .residuals_a1 import residuals_a1
from .residuals_a2 import residuals_a2
from .residuals_a3 import residuals_a3


class PolicyNetwork(nn.Module):
    def __init__(
        self,
        d_in: int,
        d_out: int,
        hidden: Tuple[int, int] = (512, 512),
        activation: str = "selu",
    ):
        super().__init__()
        act = nn.SELU if activation.lower() == "selu" else nn.ReLU
        h1, h2 = hidden
        self.net = nn.Sequential(
            nn.Linear(d_in, h1), act(),
            nn.Linear(h1, h2), act(),
            nn.Linear(h2, d_out)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def stack_residuals(res: Dict[str, torch.Tensor], keys: List[str]) -> torch.Tensor:
    return torch.stack([res[k] for k in keys], dim=-1)


def loss_from_residuals(resid: torch.Tensor) -> torch.Tensor:
    return (resid ** 2).mean()


def _gh_grid_3d(params: ModelParams, gh_n: int) -> Tuple[torch.Tensor, torch.Tensor]:
    """Precompute 3D Gauss–Hermite nodes and weights.

    Returns:
        eps_grid: (Q,3) tensor of (epsA, epsg, epst)
        w_grid:   (Q,)  tensor of product weights
    """
    gh = gauss_hermite(gh_n, params.device, params.dtype)
    nodes, weights = gh.nodes, gh.weights
    eps_grid = torch.cartesian_prod(nodes, nodes, nodes)  # (Q,3)
    w_grid = torch.cartesian_prod(weights, weights, weights).prod(dim=-1)  # (Q,)
    return eps_grid, w_grid


def expectation_operator_appendixB(
    params: ModelParams,
    st,
    gh_n: int,
    f,
    *,
    eps_grid: Optional[torch.Tensor] = None,
    w_grid: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """Appendix B expectation operator (vectorized).

    Computes:
        E_t[ f(epsA, epsg, epst, s_{t+1}) ]
      = sum_{s'} pi(s'|s_t) ∫∫∫ f(...) dN dN dN

    using a fully vectorized Gauss–Hermite grid for the three continuous shocks and
    exact Markov transition probabilities. This implementation avoids high-rank
    broadcast tensors and Python loops.
    """
    if eps_grid is None or w_grid is None:
        eps_grid, w_grid = _gh_grid_3d(params, gh_n)
    P = params.P
    dev = params.device

    B = st.Delta_prev.shape[0]
    Q = eps_grid.shape[0]

    # shocks: (B,Q,2)
    epsA = eps_grid[:, 0].view(1, Q, 1).expand(B, Q, 2)
    epsg = eps_grid[:, 1].view(1, Q, 1).expand(B, Q, 2)
    epst = eps_grid[:, 2].view(1, Q, 1).expand(B, Q, 2)

    # next regime values: (B,Q,2) with r=0 => 0, r=1 => 1
    s_next = torch.stack(
        [torch.zeros(B, Q, device=dev, dtype=torch.long), torch.ones(B, Q, device=dev, dtype=torch.long)],
        dim=-1,
    )

    val = f(epsA, epsg, epst, s_next)  # expected shape (B,Q,2) or (B,Q,2,K)

    # weights
    wq = w_grid.view(1, Q, 1)  # (1,Q,1)
    pi = torch.stack([P[0, st.s], P[1, st.s]], dim=-1).view(B, 1, 2)  # (B,1,2)

    if val.ndim == 3:
        # (B,Q,2) -> (B,)
        return (val * wq * pi).sum(dim=1).sum(dim=-1)
    if val.ndim == 4:
        # (B,Q,2,K) -> (B,K)
        wq4 = w_grid.view(1, Q, 1, 1)
        pi4 = torch.stack([P[0, st.s], P[1, st.s]], dim=-1).view(B, 1, 2, 1)
        return (val * wq4 * pi4).sum(dim=1).sum(dim=1)
    raise ValueError(f"Unexpected f output ndim={val.ndim}; expected 3 or 4")


def implied_nominal_rate_from_euler(
    params: ModelParams,
    policy: PolicyName,
    x_t: torch.Tensor,
    out_t: Dict[str, torch.Tensor],
    gh_n: int,
    trainer: "Trainer",
) -> torch.Tensor:
    """
    Recover i_t from the Fisher/Euler equation post-training:
        1 = E_t[ beta * (1+i_t)/(1+pi_{t+1}) * lam_{t+1}/lam_t ]
    => i_t = ( E_t[ beta * lam_{t+1}/(lam_t*(1+pi_{t+1})) ] )^{-1} - 1
    Only meaningful for discretion/commitment (Taylor rules pin i_t).
    """
    st = unpack_state(x_t, policy)
    lam_t = out_t["lam"]

    def x_next(epsA, epsg, epst, s_next):
        logA_n, logg_n, xi_n, s_n = shock_laws_of_motion(params, st, epsA, epsg, epst, s_next)
        Delta_cur = out_t["Delta"].view(-1, 1, 1).expand_as(logA_n)
        if policy == "commitment":
            # state stores scaled lag co-states: vp=ϑ*c^γ, rp=ϱ*c^γ
            vp_cur = (out_t["vartheta"] * out_t["c"].pow(params.gamma)).view(-1, 1, 1).expand_as(logA_n)
            rp_cur = (out_t["varrho"] * out_t["c"].pow(params.gamma)).view(-1, 1, 1).expand_as(logA_n)
            return torch.stack([Delta_cur, logA_n, logg_n, xi_n, s_n.to(x_t.dtype), vp_cur, rp_cur], dim=-1)
        return torch.stack([Delta_cur, logA_n, logg_n, xi_n, s_n.to(x_t.dtype)], dim=-1)

    def f_term(epsA, epsg, epst, s_next):
        xn = x_next(epsA, epsg, epst, s_next)
        on = trainer._policy_outputs(xn)
        return params.beta * (on["lam"] / lam_t) * (1.0 / (1.0 + on["pi"]))

    # Reuse cached GH grids from trainer when available to avoid repeated grid construction
    eps_grid = getattr(trainer, "_eps_grid", None)
    w_grid = getattr(trainer, "_w_grid", None)
    Et = expectation_operator_appendixB(params, st, gh_n, f_term, eps_grid=eps_grid, w_grid=w_grid)
    return (1.0 / Et) - 1.0


@dataclass
class Trainer:
    params: ModelParams
    cfg: TrainConfig
    policy: PolicyName
    net: PolicyNetwork
    gh_n: int = 3
    rbar_by_regime: torch.Tensor | None = None

    _eps_grid: Optional[torch.Tensor] = None
    _w_grid: Optional[torch.Tensor] = None

    # Lightweight timing accumulators (CPU-friendly)
    _t_accum: Dict[str, float] | None = None
    _t_count: int = 0

    # Last training stage summary (for reproducible logging/saving)
    last_train_stats: Dict[str, float] | None = None

    def __post_init__(self):
        # CPU knobs (safe; do not change equations)
        if self.params.device == "cpu":
            if getattr(self.cfg, "cpu_num_threads", None) is not None:
                torch.set_num_threads(int(self.cfg.cpu_num_threads))
            if getattr(self.cfg, "cpu_num_interop_threads", None) is not None:
                torch.set_num_interop_threads(int(self.cfg.cpu_num_interop_threads))
            mp = getattr(self.cfg, "matmul_precision", None)
            if mp is not None and hasattr(torch, "set_float32_matmul_precision"):
                try:
                    torch.set_float32_matmul_precision(str(mp))
                except Exception:
                    pass

        # Prefer a smaller GH order for training (can be overridden by passing gh_n)
        if hasattr(self.cfg, "gh_n_train") and self.gh_n == 3:
            self.gh_n = int(getattr(self.cfg, "gh_n_train"))

        # Cache GH grid for expectations (3 continuous shocks)
        self._eps_grid, self._w_grid = _gh_grid_3d(self.params, self.gh_n)
        self.params = self.params.to_torch()
        set_seeds(self.cfg.seed)

        if self.policy == "mod_taylor":
            if self.rbar_by_regime is None:
                raise ValueError("mod_taylor requires rbar_by_regime from export_rbar_tensor(solve_flexprice_sss(params))")
            if self.rbar_by_regime.numel() != 2:
                raise ValueError("rbar_by_regime must have 2 elements (one per regime)")

        if self.policy in ["taylor", "mod_taylor"]:
            self.res_keys = ["res_c_lam", "res_labor", "res_euler", "res_XiN", "res_XiD", "res_pstar_def", "res_calvo", "res_Delta"]
        elif self.policy == "discretion":
            self.res_keys = ["res_c_foc", "res_pi_foc", "res_pstar_foc", "res_Delta_foc",
                             "res_c_lam", "res_labor", "res_XiN_rec", "res_XiD_rec",
                             "res_pstar_def", "res_calvo", "res_Delta_law"]
        elif self.policy == "commitment":
            self.res_keys = ["res_c_foc", "res_Delta_foc", "res_pi_foc", "res_pstar_foc", "res_XiN_foc", "res_XiD_foc",
                             "res_c_lam", "res_labor", "res_XiN_rec", "res_XiD_rec",
                             "res_pstar_def", "res_calvo", "res_Delta_law"]
        else:
            raise ValueError(self.policy)

        # human-readable labels for per-equation diagnostics
        self.eq_labels = list(self.res_keys)

        # timers
        self._t_accum = {}
        self.last_train_stats = None

    def _t0(self, key: str) -> float:
        if not getattr(self.cfg, "enable_timers", True):
            return 0.0
        return time.perf_counter()

    def _t1(self, key: str, t0: float) -> None:
        if not getattr(self.cfg, "enable_timers", True):
            return
        dt = time.perf_counter() - t0
        assert self._t_accum is not None
        self._t_accum[key] = self._t_accum.get(key, 0.0) + dt

    def simulate_initial_state(self, B: int, commitment_sss: Dict | None = None) -> torch.Tensor:
        dev, dt = self.params.device, self.params.dtype
        Delta_prev = torch.ones(B, device=dev, dtype=dt) * (1.0 + 0.01 * torch.randn(B, device=dev, dtype=dt))
        logA = 0.01 * torch.randn(B, device=dev, dtype=dt)
        logg = 0.01 * torch.randn(B, device=dev, dtype=dt)
        xi = 0.01 * torch.randn(B, device=dev, dtype=dt)
        s = torch.randint(0, 2, (B,), device=dev, dtype=torch.long)

        if self.policy != "commitment":
            return torch.stack([Delta_prev, logA, logg, xi, s.to(dt)], dim=-1)

        if commitment_sss is None:
            raise ValueError("Commitment init multipliers must be provided (no zeros).")

        # commitment_sss can be either a single dict {"vartheta_prev","varrho_prev"}
        # or a regime-indexed dict {0:{...},1:{...}}.
        if isinstance(commitment_sss, dict) and 0 in commitment_sss and 1 in commitment_sss:
            vp0 = float(commitment_sss[0]["vartheta_prev"]); vp1 = float(commitment_sss[1]["vartheta_prev"])
            rp0 = float(commitment_sss[0]["varrho_prev"]);   rp1 = float(commitment_sss[1]["varrho_prev"])
            vp = torch.where(s == 0, torch.full((B,), vp0, device=dev, dtype=dt), torch.full((B,), vp1, device=dev, dtype=dt))
            rp = torch.where(s == 0, torch.full((B,), rp0, device=dev, dtype=dt), torch.full((B,), rp1, device=dev, dtype=dt))
        else:
            vp = torch.full((B,), float(commitment_sss["vartheta_prev"]), device=dev, dtype=dt)
            rp = torch.full((B,), float(commitment_sss["varrho_prev"]), device=dev, dtype=dt)

        vp = vp * (1.0 + 0.01 * torch.randn(B, device=dev, dtype=dt))
        rp = rp * (1.0 + 0.01 * torch.randn(B, device=dev, dtype=dt))
        return torch.stack([Delta_prev, logA, logg, xi, s.to(dt), vp, rp], dim=-1)

    # --------------------
    # Lightweight timing (prints averages; does not require torch.profiler)
    # --------------------
    def _timer_init(self) -> None:
        if not getattr(self.cfg, "enable_timers", True):
            self._t_accum = None
            self._t_count = 0
            return
        if self._t_accum is None:
            self._t_accum = {"refresh": 0.0, "sample": 0.0, "residuals": 0.0, "expect": 0.0, "opt": 0.0}
            self._t_count = 0

    def _tadd(self, key: str, dt: float) -> None:
        if self._t_accum is None:
            return
        self._t_accum[key] = self._t_accum.get(key, 0.0) + float(dt)

    def _treport(self, step: int) -> None:
        if self._t_accum is None:
            return
        log_every = int(getattr(self.cfg, "log_every", 50))
        if log_every <= 0 or (step + 1) % log_every != 0:
            return
        c = max(1, self._t_count)
        parts = []
        for k in ["refresh", "sample", "residuals", "expect", "opt"]:
            parts.append(f"{k}={self._t_accum.get(k, 0.0)/c:.3f}s")
        print("[timing avg] " + ", ".join(parts))
        # reset accumulators
        for k in list(self._t_accum.keys()):
            self._t_accum[k] = 0.0
        self._t_count = 0

    def _policy_outputs(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        raw = self.net(x)
        floors = {"c": self.cfg.c_floor, "Delta": self.cfg.delta_floor, "pstar": self.cfg.pstar_floor}
        return decode_outputs(self.policy, raw, floors=floors)

    def _expect_pack(self, st, out: Dict[str, torch.Tensor], x_next_builder, term_builder) -> torch.Tensor:
        """Compute multiple expectations with a single forward pass.

        term_builder receives (on_next_dict, B, Q) and must return a tensor of shape:
            (B, Q, 2, K)
        The return is (B, K) after integrating (quadrature × Markov).
        """
        assert self._eps_grid is not None and self._w_grid is not None
        dev = self.params.device
        B = st.Delta_prev.shape[0]
        Q = self._eps_grid.shape[0]

        epsA = self._eps_grid[:, 0].view(1, Q, 1).expand(B, Q, 2)
        epsg = self._eps_grid[:, 1].view(1, Q, 1).expand(B, Q, 2)
        epst = self._eps_grid[:, 2].view(1, Q, 1).expand(B, Q, 2)
        s_next = torch.stack(
            [torch.zeros(B, Q, device=dev, dtype=torch.long), torch.ones(B, Q, device=dev, dtype=torch.long)],
            dim=-1,
        )

        xn = x_next_builder(epsA, epsg, epst, s_next)               # (B,Q,2,xdim)
        xn2 = xn.reshape(B * Q * 2, xn.shape[-1])
        on = self._policy_outputs(xn2)
        # reshape every output to (B,Q,2)
        on_r = {k: v.reshape(B, Q, 2) for k, v in on.items()}

        terms = term_builder(on_r, B, Q)                            # (B,Q,2,K)

        # weights
        wq = self._w_grid.view(1, Q, 1, 1)                          # (1,Q,1,1)
        pi = torch.stack([self.params.P[0, st.s], self.params.P[1, st.s]], dim=-1).view(B, 1, 2, 1)
        Et = (terms * wq * pi).sum(dim=1).sum(dim=1)                # sum Q then regimes -> (B,K)
        return Et

    def _residuals(self, x: torch.Tensor) -> torch.Tensor:
        out = self._policy_outputs(x)
        st = unpack_state(x, self.policy)

        if self.policy in ["taylor", "mod_taylor"]:
            lam_t = out["lam"]
            lam_tg = lam_t.view(-1, 1, 1)
            if self.policy == "taylor":
                i_t = i_taylor(self.params, out["pi"])
            else:
                assert self.rbar_by_regime is not None
                i_t = i_modified_taylor(self.params, out["pi"], self.rbar_by_regime, st.s)

            i_tg = i_t.view(-1, 1, 1)

            def x_next(epsA, epsg, epst, s_next):
                logA_n, logg_n, xi_n, s_n = shock_laws_of_motion(self.params, st, epsA, epsg, epst, s_next)
                Delta_cur = out["Delta"].view(-1, 1, 1).expand_as(logA_n)
                return torch.stack([Delta_cur, logA_n, logg_n, xi_n, s_n.to(x.dtype)], dim=-1)

            def f_all(epsA, epsg, epst, s_next):
                # Single forward pass on the (eps, s_next) grid; reuse for all expectations
                xn = x_next(epsA, epsg, epst, s_next)
                on = self._policy_outputs(xn)
                Lambda = self.params.beta * on["lam"] / lam_tg

                one_plus_pi = 1.0 + on["pi"]  # safe by construction in decode_outputs
                term_XiN = self.params.theta * Lambda * one_plus_pi.pow(self.params.eps) * on["XiN"]
                term_XiD = self.params.theta * Lambda * one_plus_pi.pow(self.params.eps - 1.0) * on["XiD"]
                term_eul = fisher_euler_term(self.params, i_tg, on["pi"], on["lam"])
                return torch.stack([term_XiN, term_XiD, term_eul], dim=-1)

            t0 = time.perf_counter() if self._t_accum is not None else None
            Et_all = expectation_operator_appendixB(
                self.params, st, self.gh_n, f_all, eps_grid=self._eps_grid, w_grid=self._w_grid
            )
            if t0 is not None:
                self._tadd("expect", time.perf_counter() - t0)
            Et_XiN = Et_all[..., 0]
            Et_XiD = Et_all[..., 1]
            Et_eul = Et_all[..., 2]

            res = residuals_a1(self.params, st, out, Et_XiN, Et_XiD, Et_eul)
            return stack_residuals(res, self.res_keys)

        if self.policy == "discretion":
            lam_t = out["lam"]
            lam_tg = lam_t.view(-1, 1, 1)

            def x_next(epsA, epsg, epst, s_next):
                logA_n, logg_n, xi_n, s_n = shock_laws_of_motion(self.params, st, epsA, epsg, epst, s_next)
                Delta_cur = out["Delta"].view(-1, 1, 1).expand_as(logA_n)
                return torch.stack([Delta_cur, logA_n, logg_n, xi_n, s_n.to(x.dtype)], dim=-1)

            def f_all(epsA, epsg, epst, s_next):
                # Single forward pass on the (eps, s_next) grid; reuse for all expectations.
                xn = x_next(epsA, epsg, epst, s_next)
                on = self._policy_outputs(xn)

                one_plus_pi = 1.0 + on["pi"]  # safe by construction in decode_outputs
                Lambda = self.params.beta * on["lam"] / lam_tg

                # These follow Appendix A.2 notation:
                F = self.params.theta * self.params.beta * on["lam"] * one_plus_pi.pow(self.params.eps - 1.0) * on["XiD"]
                G = self.params.theta * self.params.beta * on["lam"] * one_plus_pi.pow(self.params.eps) * on["XiN"]

                theta_term = self.params.theta * one_plus_pi.pow(self.params.eps) * on["zeta"]
                XiN_rec = self.params.theta * Lambda * one_plus_pi.pow(self.params.eps) * on["XiN"]
                XiD_rec = self.params.theta * Lambda * one_plus_pi.pow(self.params.eps - 1.0) * on["XiD"]

                return torch.stack([F, G, theta_term, XiN_rec, XiD_rec], dim=-1)

            t0 = time.perf_counter() if self._t_accum is not None else None
            Et_all = expectation_operator_appendixB(
                self.params, st, self.gh_n, f_all, eps_grid=self._eps_grid, w_grid=self._w_grid
            )
            if t0 is not None:
                self._tadd("expect", time.perf_counter() - t0)
            Et_F = Et_all[..., 0]
            Et_G = Et_all[..., 1]
            Et_theta = Et_all[..., 2]
            Et_XiN = Et_all[..., 3]
            Et_XiD = Et_all[..., 4]

            # Strict, efficient: d/dΔ E_t[F_{t+1}] = E_t[dF_{t+1}/dΔ]
            # and similarly for G (linearity of expectation).
            Et_dF = torch.autograd.grad(Et_F.sum(), out["Delta"], create_graph=True)[0]
            Et_dG = torch.autograd.grad(Et_G.sum(), out["Delta"], create_graph=True)[0]

            res = residuals_a2(self.params, st, out, Et_F, Et_G, Et_dF, Et_dG, Et_theta, Et_XiN, Et_XiD)
            return stack_residuals(res, self.res_keys)


        if self.policy == "commitment":
            c_t = out["c"]; lam_t = out["lam"]
            c_tg = c_t.view(-1, 1, 1)
            lam_tg = lam_t.view(-1, 1, 1)

            def x_next(epsA, epsg, epst, s_next):
                logA_n, logg_n, xi_n, s_n = shock_laws_of_motion(self.params, st, epsA, epsg, epst, s_next)
                Delta_cur = out["Delta"].view(-1, 1, 1).expand_as(logA_n)
                vp_cur = (out["vartheta"] * out["c"].pow(self.params.gamma)).view(-1, 1, 1).expand_as(logA_n)
                rp_cur = (out["varrho"] * out["c"].pow(self.params.gamma)).view(-1, 1, 1).expand_as(logA_n)
                return torch.stack([Delta_cur, logA_n, logg_n, xi_n, s_n.to(x.dtype), vp_cur, rp_cur], dim=-1)

            gamma = self.params.gamma

            def f_all(epsA, epsg, epst, s_next):
                # Single forward pass on the (eps, s_next) grid; reuse for all expectations.
                xn = x_next(epsA, epsg, epst, s_next)
                on = self._policy_outputs(xn)
                one_plus_pi = 1.0 + on["pi"]
                Lambda = self.params.beta * on["lam"] / lam_tg

                XiN_rec = self.params.theta * Lambda * one_plus_pi.pow(self.params.eps) * on["XiN"]
                XiD_rec = self.params.theta * Lambda * one_plus_pi.pow(self.params.eps - 1.0) * on["XiD"]
                theta_term = self.params.theta * one_plus_pi.pow(self.params.eps) * on["zeta"]

                termN = self.params.beta * self.params.theta * gamma * c_tg.pow(gamma - 1.0) * on["lam"] * one_plus_pi.pow(self.params.eps) * on["XiN"]
                termD = self.params.beta * self.params.theta * gamma * c_tg.pow(gamma - 1.0) * on["lam"] * one_plus_pi.pow(self.params.eps - 1.0) * on["XiD"]
                return torch.stack([XiN_rec, XiD_rec, termN, termD, theta_term], dim=-1)

            t0 = time.perf_counter() if self._t_accum is not None else None
            Et_all = expectation_operator_appendixB(
                self.params, st, self.gh_n, f_all, eps_grid=self._eps_grid, w_grid=self._w_grid
            )
            if t0 is not None:
                self._tadd("expect", time.perf_counter() - t0)
            Et_XiN = Et_all[..., 0]
            Et_XiD = Et_all[..., 1]
            Et_termN = Et_all[..., 2]
            Et_termD = Et_all[..., 3]
            Et_theta = Et_all[..., 4]

            res = residuals_a3(self.params, st, out, Et_XiN, Et_XiD, Et_termN, Et_termD, Et_theta)
            return stack_residuals(res, self.res_keys)


        raise ValueError(self.policy)

    @torch.no_grad()
    def _step_state(self, x: torch.Tensor) -> torch.Tensor:
        """
        One-step law of motion for x_{t+1} (Appendix B).
        For commitment, state stores scaled co-states:
            vp_t = vartheta_t * c_t^gamma
            rp_t = varrho_t * c_t^gamma
        """
        dev, dt = self.params.device, self.params.dtype
        B = x.shape[0]
        st = unpack_state(x, self.policy)
        out = self._policy_outputs(x)

        epsA = torch.randn(B, device=dev, dtype=dt)
        epsg = torch.randn(B, device=dev, dtype=dt)
        epst = torch.randn(B, device=dev, dtype=dt)

        u = torch.rand(B, device=dev, dtype=dt)
        P = self.params.P
        p0 = P[0, st.s]
        s_next = torch.where(u < p0, torch.zeros_like(st.s), torch.ones_like(st.s))

        logA_n, logg_n, xi_n, s_n = shock_laws_of_motion(self.params, st, epsA, epsg, epst, s_next)

        if self.policy == "commitment":
            vp = out["vartheta"] * out["c"].pow(self.params.gamma)
            rp = out["varrho"] * out["c"].pow(self.params.gamma)
            return torch.stack([out["Delta"], logA_n, logg_n, xi_n, s_n.to(dt), vp, rp], dim=-1)

        return torch.stack([out["Delta"], logA_n, logg_n, xi_n, s_n.to(dt)], dim=-1)

    def train(
        self,
        B: int = 4096,
        commitment_sss: Dict | None = None,
        *,
        burn_in: int = 2000,
        refresh_frac: float = 0.25,
        fine_tune_float64: bool = True,
    ) -> List[float]:
        """
        DEQN training (simulate→residuals→Adam) + optional float64 fine-tune.
        No shortcuts: expectations per Appendix B; simulation uses laws of motion; residuals per Appendices A.1–A.3.
        """
        dev = self.params.device

        def run_stage(steps: int, lr: float, x_init: torch.Tensor) -> Tuple[List[float], torch.Tensor]:
            opt = optim.Adam(self.net.parameters(), lr=lr)
            # x_pop: population used only to generate new states (no_grad)
            x_pop = x_init
            losses: List[float] = []

            # Burn-in without gradients (for a representative state distribution)
            with torch.no_grad():
                for _ in trange(burn_in, desc=f"{self.policy} | burn-in | {x_init.dtype}", leave=False):
                    x_pop = self._step_state(x_pop)

            # timing/profiling setup
            self._timer_init()
            use_profiler = bool(getattr(self.cfg, "profile", False))
            prof_max_steps = int(getattr(self.cfg, "profile_steps", 200))
            prof = None
            if use_profiler:
                import os
                from torch.profiler import profile, ProfilerActivity, tensorboard_trace_handler
                os.makedirs(str(getattr(self.cfg, "profile_dir", "../artifacts/profiles")), exist_ok=True)
                prof = profile(
                    activities=[ProfilerActivity.CPU],
                    record_shapes=True,
                    profile_memory=True,
                    with_stack=False,
                    on_trace_ready=tensorboard_trace_handler(str(getattr(self.cfg, "profile_dir", "../artifacts/profiles"))),
                )
                prof.__enter__()

            # ---- Replay buffer ----
            buf_size = int(getattr(self.cfg, "replay_buffer_size", 120_000))
            refresh_every = int(getattr(self.cfg, "replay_refresh_every", 50))
            refresh_steps = int(getattr(self.cfg, "replay_refresh_steps", 80))
            init_fill_steps = int(getattr(self.cfg, "replay_init_fill_steps", 200))
            refresh_frac_eff = float(getattr(self.cfg, "replay_refresh_frac", refresh_frac))
            # validation / early stopping knobs (do not change equations)
            val_size = int(getattr(self.cfg, "val_size", 4096))
            val_every = int(getattr(self.cfg, "val_every", 500))
            early_stop = bool(getattr(self.cfg, "early_stopping", False))
            patience = int(getattr(self.cfg, "patience", 5000))
            min_delta = float(getattr(self.cfg, "min_delta", 1e-5))
            reduce_on_plateau = bool(getattr(self.cfg, "reduce_lr_on_plateau", False))
            plateau_patience = int(getattr(self.cfg, "plateau_patience", 5000))
            lr_reduce_factor = float(getattr(self.cfg, "lr_reduce_factor", 0.5))
            min_lr = float(getattr(self.cfg, "min_lr", 1e-7))


            xdim = x_pop.shape[-1]
            X_buf = torch.empty((buf_size, xdim), device=dev, dtype=x_init.dtype)
            buf_ptr = 0
            buf_filled = 0

            # Expose buffer view for post-training diagnostics (e.g., RMSE reports)
            self.replay = ReplayView(X_buf, lambda: buf_filled)

            def add_to_buffer(states: torch.Tensor) -> None:
                nonlocal buf_ptr, buf_filled
                if states.ndim != 2:
                    states = states.reshape(-1, xdim)
                n = states.shape[0]
                if n == 0:
                    return
                # write with wrap-around
                end = buf_ptr + n
                if end <= buf_size:
                    X_buf[buf_ptr:end] = states
                else:
                    first = buf_size - buf_ptr
                    X_buf[buf_ptr:] = states[:first]
                    X_buf[:end - buf_size] = states[first:]
                buf_ptr = end % buf_size
                buf_filled = min(buf_size, buf_filled + n)

            # initial fill
            with torch.no_grad():
                cur = x_pop
                for _ in range(init_fill_steps):
                    cur = self._step_state(cur)
                    add_to_buffer(cur)
                x_pop = cur

            # fixed validation set sampled once from the replay buffer
            with torch.no_grad():
                if val_size > 0 and buf_filled > 0:
                    vidx = torch.randint(0, buf_filled, (val_size,), device=dev)
                    X_val = X_buf[vidx].clone()
                else:
                    X_val = None

            self.X_val = X_val

            best_val = float("inf")
            best_it = 0
            plateau_it = 0

            # Optional: save best checkpoint during training (by validation loss)
            run_dir = getattr(self.cfg, "run_dir", None)
            save_best = bool(getattr(self.cfg, "save_best", False))
            best_name = str(getattr(self.cfg, "best_weights_name", "weights_best.pt"))
            _best_saved = False


            for it in trange(steps, desc=f"{self.policy} | train | {x_init.dtype}", leave=True):
                t_it0 = time.perf_counter()
                # sample training batch from replay buffer
                t0 = time.perf_counter()
                max_idx = buf_filled if buf_filled > 0 else x_pop.shape[0]
                if buf_filled > 0:
                    idx = torch.randint(0, max_idx, (self.cfg.batch_size,), device=dev)
                    xb = X_buf[idx]
                else:
                    idx = torch.randint(0, x_pop.shape[0], (self.cfg.batch_size,), device=dev)
                    xb = x_pop[idx]

                self._tadd("sample", time.perf_counter() - t0)

                t0 = time.perf_counter()
                resid = self._residuals(xb)
                loss = loss_from_residuals(resid)

                # lightweight quality print (uses current batch residuals)
                log_every = int(getattr(self.cfg, "log_every", 200))
                topk = int(getattr(self.cfg, "quality_topk", 3))
                if log_every > 0 and ((it + 1) % log_every == 0):
                    with torch.no_grad():
                        train_loss = float(loss.detach().cpu())
                        train_rmse = float(torch.sqrt(loss.detach()).cpu())
                        rmse_eq = torch.sqrt((resid.detach() ** 2).mean(dim=0))
                        k = min(topk, rmse_eq.numel())
                        worst_idx = torch.topk(rmse_eq, k=k).indices.tolist()
                        labels = getattr(self, "res_keys", [f"eq{i}" for i in range(rmse_eq.numel())])
                        worst = ", ".join([f"{labels[j]}:{rmse_eq[j].item():.2e}" for j in worst_idx])
                    print(f"[quality] it={it+1}/{steps} train_loss={train_loss:.3e} train_RMSE={train_rmse:.3e} worst={worst}")
                self._tadd("residuals", time.perf_counter() - t0)

                t0 = time.perf_counter()
                opt.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.net.parameters(), self.cfg.grad_clip)
                opt.step()
                self._tadd("opt", time.perf_counter() - t0)
                losses.append(float(loss.detach().cpu()))

                # validation (fixed set) + early stopping / LR on plateau
                if X_val is not None and val_every > 0 and ((it + 1) % val_every == 0):
                    t0v = time.perf_counter()
                    if self.policy in ("discretion", "commitment"):
                        with torch.enable_grad():
                            vres = self._residuals(X_val)
                            vloss_t = loss_from_residuals(vres)
                            vloss = float(vloss_t.detach().cpu())
                    else:
                        with torch.inference_mode():
                            vres = self._residuals(X_val)
                            vloss = float(loss_from_residuals(vres).detach().cpu())
                    self._tadd("val", time.perf_counter() - t0v)

                    improved = (vloss < (best_val - min_delta))
                    if improved:
                        best_val = vloss
                        best_it = int(it + 1)
                        plateau_it = 0

                        # Save best checkpoint if requested and run_dir is available
                        if save_best and run_dir:
                            try:
                                from .io_utils import save_torch, save_json
                                import os
                                save_torch(os.path.join(run_dir, best_name), self.net.state_dict())
                                save_json(os.path.join(run_dir, "best_checkpoint.json"), {
                                    "best_val": float(best_val),
                                    "best_step": int(best_it),
                                    "metric": "val_loss",
                                })
                                _best_saved = True
                            except Exception as e:
                                # Do not fail training because of I/O.
                                if getattr(self.cfg, "enable_timers", True):
                                    print(f"[warn] failed to save best checkpoint: {e}")
                    else:
                        plateau_it += val_every

                    # Reduce LR on plateau if requested (useful when early_stopping=False)
                    if reduce_on_plateau and plateau_it >= plateau_patience:
                        for g in opt.param_groups:
                            new_lr = max(float(min_lr), float(g["lr"]) * float(lr_reduce_factor))
                            g["lr"] = new_lr
                        plateau_it = 0

                    # Early stopping
                    if early_stop and (int(it + 1) - best_it) >= patience:
                        if getattr(self.cfg, "enable_timers", True):
                            print(f"[early stop] step={it+1} best_val={best_val:.6g} last_val={vloss:.6g} best_step={best_it}")
                        break

                # refresh replay buffer occasionally (no_grad)
                if (it + 1) % refresh_every == 0:
                    t0 = time.perf_counter()
                    with torch.no_grad():
                        cur = x_pop
                        for _ in range(refresh_steps):
                            cur = self._step_state(cur)
                            add_to_buffer(cur)
                        # optionally reinitialize a fraction of the population to maintain coverage
                        n_ref = int(refresh_frac_eff * cur.shape[0])
                        if n_ref > 0:
                            ridx = torch.randint(0, cur.shape[0], (n_ref,), device=dev)
                            cur[ridx] = self.simulate_initial_state(
                                n_ref,
                                commitment_sss=commitment_sss if self.policy == "commitment" else None,
                            )
                        x_pop = cur
                    self._tadd("refresh", time.perf_counter() - t0)

                if self._t_accum is not None:
                    self._t_count += 1
                    self._treport(it)

                if prof is not None:
                    prof.step()
                    if (it + 1) >= prof_max_steps:
                        prof.__exit__(None, None, None)
                        prof = None

            if prof is not None:
                prof.__exit__(None, None, None)

            # store a small summary for the caller (useful for reproducible saving)
            try:
                cur_lr = float(opt.param_groups[0]["lr"])
            except Exception:
                cur_lr = float("nan")
            self.last_train_stats = {
                "best_val": float(best_val),
                "best_step": float(best_it),
                "steps_done": float(len(losses)),
                "final_lr": float(cur_lr),
                "best_saved": bool(_best_saved),
                "run_dir": str(run_dir) if run_dir else None,
            }

            return losses, x_pop

        # ---- stage 1 (float32 / current dtype) ----
        x0 = self.simulate_initial_state(
            B,
            commitment_sss=commitment_sss if self.policy == "commitment" else None,
        ).to(device=dev, dtype=self.params.dtype)

        losses_all: List[float] = []
        losses1, x_end = run_stage(self.cfg.steps, self.cfg.lr, x0)
        losses_all.extend(losses1)

        # ---- stage 2 (float64 fine-tune) ----
        if fine_tune_float64 and getattr(self.cfg, "fine_tune_steps", 0) > 0:
            self.params = ModelParams(
                beta=self.params.beta, gamma=self.params.gamma, omega=self.params.omega,
                theta=self.params.theta, eps=self.params.eps, tau_bar=self.params.tau_bar,
                rho_A=self.params.rho_A, rho_tau=self.params.rho_tau, rho_g=self.params.rho_g,
                sigma_A=self.params.sigma_A, sigma_tau=self.params.sigma_tau, sigma_g=self.params.sigma_g,
                g_bar=self.params.g_bar, eta_bar=self.params.eta_bar,
                p12=self.params.p12, p21=self.params.p21,
                pi_bar=self.params.pi_bar, psi=self.params.psi,
                device=self.params.device, dtype=torch.float64
            ).to_torch()

            self.net = self.net.to(dev).double()
            x_end = x_end.to(device=dev, dtype=torch.float64)

            losses2, _ = run_stage(self.cfg.fine_tune_steps, self.cfg.fine_tune_lr, x_end)
            losses_all.extend(losses2)

        return losses_all


@torch.no_grad()
def simulate_paths(
    params: ModelParams,
    policy: PolicyName,
    net: PolicyNetwork,
    T: int,
    burn_in: int,
    x0: torch.Tensor,
    rbar_by_regime: torch.Tensor | None = None,
    *,
    compute_implied_i: bool = False,
    gh_n: int = 7,
    store_states: bool = True,
) -> Dict[str, np.ndarray]:
    """
    Forward simulation under a trained policy network.
    """
    dev, dt = params.device, params.dtype
    net.eval()
    B = x0.shape[0]
    x = x0.to(device=dev, dtype=dt)

    trainer = Trainer(params=params, cfg=TrainConfig(seed=0), policy=policy, net=net, gh_n=gh_n, rbar_by_regime=rbar_by_regime)

    keep = T - burn_in
    store = {
        "c": np.zeros((keep, B)),
        "pi": np.zeros((keep, B)),
        "pstar": np.zeros((keep, B)),
        "Delta": np.zeros((keep, B)),
        "y": np.zeros((keep, B)),
        "h": np.zeros((keep, B)),
        "g": np.zeros((keep, B)),
        "tau": np.zeros((keep, B)),
        "s": np.zeros((keep, B), dtype=np.int64),
        "i": np.zeros((keep, B)),
    }
    if store_states:
        store["logA"] = np.zeros((keep, B))
        store["loggtilde"] = np.zeros((keep, B))
        store["xi"] = np.zeros((keep, B))

    if policy == "commitment":
        store["vartheta_prev"] = np.zeros((keep, B))
        store["varrho_prev"] = np.zeros((keep, B))

    for t in range(T):
        out = trainer._policy_outputs(x)
        st = unpack_state(x, policy)
        ids = identities(params, st, out)

        if policy in ["taylor", "mod_taylor"]:
            if policy == "taylor":
                i_t = i_taylor(params, out["pi"])
            else:
                assert rbar_by_regime is not None
                i_t = i_modified_taylor(params, out["pi"], rbar_by_regime, st.s)
        else:
            if compute_implied_i:
                i_t = implied_nominal_rate_from_euler(params, policy, x, out, gh_n, trainer)
            else:
                i_t = torch.full_like(out["pi"], float("nan"))

        if t >= burn_in:
            k = t - burn_in
            store["c"][k] = out["c"].cpu().numpy()
            store["pi"][k] = out["pi"].cpu().numpy()
            store["pstar"][k] = out["pstar"].cpu().numpy()
            store["Delta"][k] = out["Delta"].cpu().numpy()
            store["y"][k] = ids["y"].cpu().numpy()
            store["h"][k] = ids["h"].cpu().numpy()
            store["g"][k] = ids["g"].cpu().numpy()
            store["tau"][k] = (ids["one_plus_tau"] - 1.0).cpu().numpy()
            store["s"][k] = st.s.cpu().numpy()
            store["i"][k] = i_t.cpu().numpy()
            if store_states:
                store["logA"][k] = st.logA.cpu().numpy()
                store["loggtilde"][k] = st.loggtilde.cpu().numpy()
                store["xi"][k] = st.xi.cpu().numpy()
            if policy == "commitment":
                store["vartheta_prev"][k] = st.vartheta_prev.cpu().numpy()
                store["varrho_prev"][k] = st.varrho_prev.cpu().numpy()

        # step state (same as trainer)
        x = trainer._step_state(x)

    return store