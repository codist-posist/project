from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Tuple, Callable
import numpy as np
import torch

def _robust_solve(J: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Robust linear solve for Newton steps (handles near-singular Jacobians).

    Strategy:
      1) try direct solve
      2) try Tikhonov-regularized solves (J + λI)
      3) fall back to least-squares solution
    """
    try:
        return torch.linalg.solve(J, b)
    except Exception:
        pass

    n = J.shape[0]
    I = torch.eye(n, dtype=J.dtype, device=J.device)
    lam = torch.tensor(1e-10, dtype=J.dtype, device=J.device)
    for _ in range(10):
        try:
            return torch.linalg.solve(J + lam * I, b)
        except Exception:
            lam = lam * 10.0

    # Least-squares fallback (minimum-norm if underdetermined)
    return torch.linalg.lstsq(J, b).solution



from .config import ModelParams
from .policy_rules import i_taylor, i_modified_taylor


@dataclass
class FlexSSS:
    by_regime: Dict[int, Dict[str, float]]


def solve_flexprice_sss(params: ModelParams, max_iter: int = 20000, tol: float = 1e-14) -> FlexSSS:
    """
    Flex-price (efficient) allocation per regime, as in the paper's definition of the natural rate.
    We solve for c in each regime from:
        (c+g)^omega = 1 / ((1 + eta*M) * c^gamma)
    with eta=0 (normal) or eta=eta_bar (bad). A=1, g=g_bar.
    """
    M = params.M
    gbar = params.g_bar
    gamma = params.gamma
    omega = params.omega

    def f(c: float, eta: float) -> float:
        return (c + gbar) ** omega - 1.0 / ((1.0 + eta * M) * (c ** gamma))

    out: Dict[int, Dict[str, float]] = {}
    for s in [0, 1]:
        eta = 0.0 if s == 0 else params.eta_bar
        c = 1.0
        for _ in range(max_iter):
            val = f(c, eta)
            dval = omega * (c + gbar) ** (omega - 1.0) + gamma / ((1.0 + eta * M) * (c ** (gamma + 1.0)))
            c_new = max(1e-12, c - val / dval)
            if abs(c_new - c) < tol:
                c = c_new
                break
            c = c_new
        out[s] = {"c": float(c), "pi": 0.0, "Delta": 1.0, "pstar": 1.0}

    # Natural rate in each regime: r*_s = 1/(beta E[m_{t+1}]) - 1, where the expectation is over next regime only.
    P = params.P.detach().cpu().numpy()
    c0, c1 = out[0]["c"], out[1]["c"]

    def r_star(s: int) -> float:
        c_s = c0 if s == 0 else c1
        pi0 = P[0, s]
        pi1 = P[1, s]
        # m_{t+1} = (c_{t+1}/c_t)^(-gamma) (since u'(c)=c^{-gamma})
        E_marg = pi0 * ((c0 / c_s) ** (-params.gamma)) + pi1 * ((c1 / c_s) ** (-params.gamma))
        return 1.0 / (params.beta * E_marg) - 1.0

    out[0]["r_star"] = float(r_star(0))
    out[1]["r_star"] = float(r_star(1))
    return FlexSSS(by_regime=out)



@dataclass
class TaylorSSS:
    by_regime: Dict[int, Dict[str, float]]

def solve_taylor_sss(params: ModelParams, flex: FlexSSS) -> TaylorSSS:
    """
    SSS under the Taylor rule (Section 7, eq. (25) in the paper), regime by regime.
    Uses r_star(s) from the flex-price allocation as the regime-dependent natural rate r_{s,ss}.
    The Taylor-rule intercept targets rbar = 1/beta - 1 + pi_bar (efficient non-stochastic SS real rate).
    """
    psi = params.psi
    if abs(psi - 1.0) < 1e-12:
        raise ValueError("Taylor-rule slope psi must differ from 1 for eq. (25).")

    rbar = (1.0 / params.beta) - 1.0 + params.pi_bar
    out: Dict[int, Dict[str, float]] = {}

    for s in [0, 1]:
        r_ss = float(flex.by_regime[s]["r_star"])
        pi_ss = float(params.pi_bar + (r_ss - rbar) / (psi - 1.0))
        i_ss = float(rbar + params.pi_bar + psi * (pi_ss - params.pi_bar))  # eq. (24) with pi_bar=0 in paper

        # Calvo SS objects implied by (pi_ss)
        theta = params.theta
        eps = params.eps
        one_plus_pi = 1.0 + pi_ss
        # pstar from price index: 1 = theta(1+pi)^{eps-1} + (1-theta)pstar^{1-eps}
        base = (1.0 - theta * (one_plus_pi ** (eps - 1.0))) / (1.0 - theta)
        # Numerical safety: base must be positive; otherwise pi_ss is outside feasible region.
        if base <= 0:
            raise ValueError(f"Taylor SSS infeasible in regime {s}: implied base<=0. Try checking calibration.")
        pstar = base ** (1.0 / (1.0 - eps))
        # Delta from SS law: Delta = (1-theta)pstar^{-eps} / (1 - theta(1+pi)^eps)
        denom = 1.0 - theta * (one_plus_pi ** eps)
        if denom <= 0:
            raise ValueError(f"Taylor SSS infeasible in regime {s}: denom<=0 in Delta law.")
        Delta = (1.0 - theta) * (pstar ** (-eps)) / denom

        out[s] = {"pi": pi_ss, "i": i_ss, "r": r_ss, "pstar": float(pstar), "Delta": float(Delta)}
    return TaylorSSS(by_regime=out)

def export_rbar_tensor(params: ModelParams, flex: FlexSSS) -> torch.Tensor:
    return torch.tensor([flex.by_regime[0]["r_star"], flex.by_regime[1]["r_star"]], device=params.device, dtype=params.dtype)


def _newton_solve(
    f: Callable[[torch.Tensor], torch.Tensor],
    x0: torch.Tensor,
    *,
    max_iter: int = 200,
    tol: float = 1e-12,
    damping: float = 1.0,
) -> torch.Tensor:
    """Small damped Newton solver using autograd Jacobian (exact, no approximations)."""
    x = x0.clone()
    for _ in range(max_iter):
        x = x.detach().requires_grad_(True)
        r = f(x)
        norm = torch.max(torch.abs(r)).item()
        if norm < tol:
            return x.detach()
        J = torch.autograd.functional.jacobian(f, x, create_graph=False)
        # Solve J dx = -r
        dx = torch.linalg.solve(J, -r)
        x = (x + damping * dx).detach()
    return x.detach()


def commitment_local_ss(params: ModelParams, regime: int) -> Dict[str, float]:
    """
    Local (no-regime-switching) steady state for commitment (Appendix A.3 equations),
    used ONLY for principled initialization of lagged co-states (vartheta_prev, varrho_prev).
    This removes the previous heuristic and pins multipliers from the actual FOCs.
    Regime enters only through eta (0 or eta_bar), hence (1+tau).
    """
    assert regime in (0, 1)
    dev, dt = params.device, params.dtype

    g = torch.tensor(params.g_bar, device=dev, dtype=dt)
    eta = torch.tensor(0.0 if regime == 0 else params.eta_bar, device=dev, dtype=dt)
    one_plus_tau = torch.tensor(1.0 - params.tau_bar, device=dev, dtype=dt) + eta
    A = torch.tensor(1.0, device=dev, dtype=dt)

    beta = params.beta
    gamma = params.gamma
    omega = params.omega
    eps = params.eps
    theta = params.theta
    M = params.M

    # unknown vector: [c, pi, pstar, lam, w, XiN, XiD, Delta, mu, nu, zeta, vartheta, varrho]
    def unpack(u: torch.Tensor) -> Tuple[torch.Tensor, ...]:
        return tuple(u[i] for i in range(13))

    def residual(u: torch.Tensor) -> torch.Tensor:
        c, pi, pstar, lam, w, XiN, XiD, Delta, mu, nu, zeta, vartheta, varrho = unpack(u)

        # enforce positivity where needed by squaring (keeps Newton stable and exact)
        c = c**2 + 1e-12
        Delta = Delta**2 + 1e-12
        pstar = pstar**2 + 1e-12
        XiN = XiN**2 + 1e-14
        XiD = XiD**2 + 1e-14

        y = c + g
        h = y * Delta / A

        # SDF in SS: Lambda = beta * lam_next/lam = beta
        # Recursions in SS:
        Et_XiN = theta * beta * (1.0 + pi) ** eps * XiN
        Et_XiD = theta * beta * (1.0 + pi) ** (eps - 1.0) * XiD

        # Terms in commitment FOCs (SS, no switching):
        Et_termN = beta * theta * gamma * c.pow(gamma - 1.0) * c.pow(-gamma) * (1.0 + pi) ** eps * XiN
        Et_termD = beta * theta * gamma * c.pow(gamma - 1.0) * c.pow(-gamma) * (1.0 + pi) ** (eps - 1.0) * XiD
        Et_theta_zeta_pi = theta * (1.0 + pi) ** eps * zeta

        # vp = vartheta_prev_scaled = vartheta * c^gamma ; rp similarly
        vp = vartheta * c.pow(gamma)
        rp = varrho * c.pow(gamma)

        # --- 13 equations (Appendix A.3 full system, SS specialization) ---
        res = []

        # (1) c FOC
        term_util = c.pow(-gamma) - (y * Delta / A).pow(1.0 + omega)
        term_vartheta_now = (((1.0 + omega) * c + gamma * y) * y.pow(omega) * c.pow(gamma - 1.0) * (Delta / A).pow(omega) * one_plus_tau / A) + Et_termN
        term_vartheta_lag = (-gamma) * theta * vp * c.pow(-gamma - 1.0) * (1.0 + pi) ** eps * XiN
        term_varrho_now = 1.0 + Et_termD
        term_varrho_lag = (-gamma) * theta * rp * c.pow(-gamma - 1.0) * (1.0 + pi) ** (eps - 1.0) * XiD
        res.append(term_util + vartheta * term_vartheta_now + term_vartheta_lag + varrho * term_varrho_now + term_varrho_lag)

        # (2) Delta FOC
        disutil_over_D = -(y * Delta / A).pow(1.0 + omega) / Delta
        res.append(disutil_over_D - zeta + beta * Et_theta_zeta_pi + vartheta * omega * y.pow(1.0 + omega) * c.pow(gamma) * (Delta / A).pow(omega) * (1.0 / Delta) * one_plus_tau / A)

        Delta_prev_exp = Delta  # no-switching local SS
        # (3) pi FOC (Delta_prev=Delta in SS)
        res.append(
            nu * theta * (eps - 1.0) * (1.0 + pi).pow(eps - 2.0)
            + zeta * theta * eps * (1.0 + pi).pow(eps - 1.0) * Delta_prev_exp
            + eps * theta * vp * c.pow(-gamma) * (1.0 + pi).pow(eps - 1.0) * XiN
            + (eps - 1.0) * theta * rp * c.pow(-gamma) * (1.0 + pi).pow(eps - 2.0) * XiD
        )

        # (4) pstar FOC
        res.append(-mu * XiD + nu * (1.0 - theta) * (1.0 - eps) * pstar.pow(-eps) + zeta * (1.0 - theta) * (-eps) * pstar.pow(-eps - 1.0))

        # (5) XiN FOC
        res.append(mu * M - vartheta + theta * vp * c.pow(-gamma) * (1.0 + pi).pow(eps))

        # (6) XiD FOC
        res.append(-mu * pstar - varrho + theta * rp * c.pow(-gamma) * (1.0 + pi).pow(eps - 1.0))

        # (7) c^{-gamma} = lam
        res.append(c.pow(-gamma) - lam)

        # (8) labor: h^omega = w lam
        res.append(h.pow(omega) - w * lam)

        # (9) XiN recursion
        res.append(XiN - (y * w * one_plus_tau / A) - Et_XiN)

        # (10) XiD recursion
        res.append(XiD - y - Et_XiD)

        # (11) pstar def
        res.append(pstar - (M * XiN / XiD))

        # (12) Calvo price index
        res.append(1.0 - (theta * (1.0 + pi).pow(eps - 1.0) + (1.0 - theta) * pstar.pow(1.0 - eps)))

        # (13) Delta law (Delta_prev=Delta)
        res.append(Delta - (theta * (1.0 + pi).pow(eps) * Delta + (1.0 - theta) * pstar.pow(-eps)))

        return torch.stack(res)

    # Initial guess near efficient SS
    c0 = torch.tensor(1.0, device=dev, dtype=dt)
    u0 = torch.zeros(13, device=dev, dtype=dt)
    u0[0] = torch.sqrt(c0)  # c via square
    u0[1] = 0.0            # pi
    u0[2] = 1.0            # pstar via square
    u0[3] = 1.0            # lam
    u0[4] = 1.0            # w
    u0[5] = 1.0            # XiN via square
    u0[6] = 1.0            # XiD via square
    u0[7] = 1.0            # Delta via square
    u0[8] = 0.1            # mu
    u0[9] = 0.1            # nu
    u0[10] = 0.1           # zeta
    u0[11] = 0.1           # vartheta
    u0[12] = -0.1          # varrho

    sol = _newton_solve(residual, u0, max_iter=200, tol=1e-10, damping=0.5)

    c, pi, pstar, lam, w, XiN, XiD, Delta, mu, nu, zeta, vartheta, varrho = [sol[i].item() for i in range(13)]
    c = c*c + 1e-12
    Delta = Delta*Delta + 1e-12
    pstar = pstar*pstar + 1e-12
    XiN = XiN*XiN + 1e-14
    XiD = XiD*XiD + 1e-14

    # scaled lag co-states used in our state vector:
    vartheta_prev = float(vartheta * (c ** gamma))
    varrho_prev = float(varrho * (c ** gamma))

    return {
        "c": float(c),
        "pi": float(pi),
        "pstar": float(pstar),
        "lam": float(lam),
        "w": float(w),
        "XiN": float(XiN),
        "XiD": float(XiD),
        "Delta": float(Delta),
        "mu": float(mu),
        "nu": float(nu),
        "zeta": float(zeta),
        "vartheta": float(vartheta),
        "varrho": float(varrho),
        "vartheta_prev": vartheta_prev,
        "varrho_prev": varrho_prev,
        "regime": int(regime),
    }


def commitment_init_by_regime(params: ModelParams) -> Dict[int, Dict[str, float]]:
    """Return principled (no-heuristic) commitment init multipliers for both regimes."""
    return {0: commitment_local_ss(params, 0), 1: commitment_local_ss(params, 1)}



@dataclass
class CommitmentSSS:
    by_regime: Dict[int, Dict[str, float]]


def solve_commitment_sss_switching(params: ModelParams, max_iter: int = 200, tol: float = 1e-12, damping: float = 1.0) -> CommitmentSSS:
    """
    Stochastic steady state (SSS) under commitment with regime switching (only Markov switching; no continuous shocks),
    solving the full Appendix A.3 system in each regime with expectations over next regime.

    We solve for regime-dependent vectors u_s (13 vars) such that residuals in both regimes are zero.
    """
    dev, dt = params.device, params.dtype
    beta, gamma, omega, eps, theta, M = params.beta, params.gamma, params.omega, params.eps, params.theta, params.M

    P = params.P  # [s_next, s] as tensor

    g = torch.tensor(params.g_bar, device=dev, dtype=dt)
    A = torch.tensor(1.0, device=dev, dtype=dt)
    xi = torch.tensor(0.0, device=dev, dtype=dt)
    eta0 = torch.tensor(0.0, device=dev, dtype=dt)
    eta1 = torch.tensor(params.eta_bar, device=dev, dtype=dt)

    def one_plus_tau(s: int) -> torch.Tensor:
        eta = eta0 if s==0 else eta1
        return torch.tensor(1.0 - params.tau_bar, device=dev, dtype=dt) + xi + eta

    # Unknowns per regime: [c, pi, pstar, lam, w, XiN, XiD, Delta, mu, nu, zeta, vartheta, varrho]
    def unpack(u: torch.Tensor):
        return tuple(u[i] for i in range(13))

    def pack(U0: torch.Tensor, U1: torch.Tensor) -> torch.Tensor:
        return torch.cat([U0, U1], dim=0)

    def split(Z: torch.Tensor):
        return Z[:13], Z[13:]

    def residual_regime(u: torch.Tensor, s: int, u0_next: torch.Tensor, u1_next: torch.Tensor) -> torch.Tensor:
        c, pi, pstar, lam, w, XiN, XiD, Delta, mu, nu, zeta, vartheta, varrho = unpack(u)
        # enforce positivity exactly by squaring; this is a reparameterization, not an approximation.
        c = c**2 + 1e-12
        Delta = Delta**2 + 1e-12
        pstar = pstar**2 + 1e-12
        XiN = XiN**2 + 1e-14
        XiD = XiD**2 + 1e-14

        y = c + g
        h = y * Delta / A
        optau = one_plus_tau(s)

        # next regime values
        def decode_next(u_next):
            cN, piN, pstarN, lamN, wN, XiNN, XiDN, DeltaN, muN, nuN, zetaN, varthetaN, varrhoN = unpack(u_next)
            cN = cN**2 + 1e-12
            DeltaN = DeltaN**2 + 1e-12
            pstarN = pstarN**2 + 1e-12
            XiNN = XiNN**2 + 1e-14
            XiDN = XiDN**2 + 1e-14
            return cN, piN, pstarN, lamN, wN, XiNN, XiDN, DeltaN, muN, nuN, zetaN, varthetaN, varrhoN

        c0, pi0, pstar0, lam0, w0, XiN0, XiD0, Delta0, mu0, nu0, zeta0, vartheta0, varrho0 = decode_next(u0_next)
        c1, pi1, pstar1, lam1, w1, XiN1, XiD1, Delta1, mu1, nu1, zeta1, vartheta1, varrho1 = decode_next(u1_next)

        # SDF: Lambda = beta * lam_next/lam
        Lam0 = beta * (lam0/lam)
        Lam1 = beta * (lam1/lam)

        # Expectations over next regime
        pi0w = P[0, s]; pi1w = P[1, s]
        Et_XiN = theta * (pi0w * (Lam0*(1.0+pi0).pow(eps)*XiN0) + pi1w * (Lam1*(1.0+pi1).pow(eps)*XiN1))
        Et_XiD = theta * (pi0w * (Lam0*(1.0+pi0).pow(eps-1.0)*XiD0) + pi1w * (Lam1*(1.0+pi1).pow(eps-1.0)*XiD1))

        Et_theta_zeta_pi = (pi0w * (theta*(1.0+pi0).pow(eps)*zeta0) + pi1w * (theta*(1.0+pi1).pow(eps)*zeta1))

        Et_termN = beta*theta*gamma*c.pow(gamma-1.0) * (pi0w*(c0.pow(-gamma)*(1.0+pi0).pow(eps)*XiN0) + pi1w*(c1.pow(-gamma)*(1.0+pi1).pow(eps)*XiN1))
        Et_termD = beta*theta*gamma*c.pow(gamma-1.0) * (pi0w*(c0.pow(-gamma)*(1.0+pi0).pow(eps-1.0)*XiD0) + pi1w*(c1.pow(-gamma)*(1.0+pi1).pow(eps-1.0)*XiD1))

        # lagged co-states in regime s: vartheta_prev and varrho_prev are states; in SSS they are regime dependent.
        # Expected price dispersion from previous period conditional on current regime (paper, switching SSS)
        Delta_prev_exp = P[0, s] * Delta0 + P[1, s] * Delta1

        # Scaled co-states (paper uses ϑ_{t-1} c_{t-1}^γ and ϱ_{t-1} c_{t-1}^γ)
        vp0 = vartheta0 * c0.pow(gamma)
        vp1 = vartheta1 * c1.pow(gamma)
        rp0 = varrho0 * c0.pow(gamma)
        rp1 = varrho1 * c1.pow(gamma)
        # In switching SSS, lagged objects are conditional expectations given current regime s (as in paper's treatment of Δ_{t-1})
        vp_prev_exp = P[0, s] * vp0 + P[1, s] * vp1
        rp_prev_exp = P[0, s] * rp0 + P[1, s] * rp1

        res = []

        term_util = c.pow(-gamma) - (y * Delta / A).pow(1.0 + omega)
        term_vartheta_now = (((1.0 + omega) * c + gamma * y) * y.pow(omega) * c.pow(gamma - 1.0) * (Delta / A).pow(omega) * optau / A) + Et_termN
        term_vartheta_lag = (-gamma) * theta * vp_prev_exp * c.pow(-gamma - 1.0) * (1.0 + pi).pow(eps) * XiN
        term_varrho_now = 1.0 + Et_termD
        term_varrho_lag = (-gamma) * theta * rp_prev_exp * c.pow(-gamma - 1.0) * (1.0 + pi).pow(eps - 1.0) * XiD
        res.append(term_util + vartheta * term_vartheta_now + term_vartheta_lag + varrho * term_varrho_now + term_varrho_lag)

        disutil_over_D = -(y * Delta / A).pow(1.0 + omega) / Delta
        res.append(disutil_over_D - zeta + beta * Et_theta_zeta_pi + vartheta * omega * y.pow(1.0 + omega) * c.pow(gamma) * (Delta / A).pow(omega) * (1.0 / Delta) * optau / A)

        # For SSS, Delta_prev depends on current regime; we use Delta as the regime-specific steady dispersion.
        res.append(
            nu * theta * (eps - 1.0) * (1.0 + pi).pow(eps - 2.0)
            + zeta * theta * eps * (1.0 + pi).pow(eps - 1.0) * Delta_prev_exp
            + eps * theta * vp_prev_exp * c.pow(-gamma) * (1.0 + pi).pow(eps - 1.0) * XiN
            + (eps - 1.0) * theta * rp_prev_exp * c.pow(-gamma) * (1.0 + pi).pow(eps - 2.0) * XiD
        )

        res.append(-mu * XiD + nu * (1.0 - theta) * (1.0 - eps) * pstar.pow(-eps) + zeta * (1.0 - theta) * (-eps) * pstar.pow(-eps - 1.0))

        res.append(mu * M - vartheta + theta * vp_prev_exp * c.pow(-gamma) * (1.0 + pi).pow(eps))
        res.append(-mu * pstar - varrho + theta * rp_prev_exp * c.pow(-gamma) * (1.0 + pi).pow(eps - 1.0))

        res.append(c.pow(-gamma) - lam)
        res.append(h.pow(omega) - w * lam)

        res.append(XiN - (y * w * optau / A) - Et_XiN)
        res.append(XiD - y - Et_XiD)

        res.append(pstar - (M * XiN / XiD))
        res.append(1.0 - (theta * (1.0 + pi).pow(eps - 1.0) + (1.0 - theta) * pstar.pow(1.0 - eps)))

        # Delta law uses Delta_prev = Delta_s (same regime), since SSS conditions are conditional on regime.
        res.append(Delta - (theta * (1.0 + pi).pow(eps) * Delta + (1.0 - theta) * pstar.pow(-eps)))

        return torch.stack(res)

    def F(Z: torch.Tensor) -> torch.Tensor:
        U0, U1 = split(Z)
        # in SSS, next-period u depends on s_next; so residual in regime s uses u0_next=U0, u1_next=U1
        r0 = residual_regime(U0, 0, U0, U1)
        r1 = residual_regime(U1, 1, U0, U1)
        return torch.cat([r0, r1], dim=0)

    # initial guess: use local SS in each regime (already implemented) if available
    loc0 = torch.tensor(list(commitment_local_ss(params, 0).values()), device=dev, dtype=dt)
    loc1 = torch.tensor(list(commitment_local_ss(params, 1).values()), device=dev, dtype=dt)
    # commitment_local_ss returns dict with keys; ensure ordering
    # We'll build U from those dicts in the right order.
    def u_from_dict(d):
        return torch.tensor([d["c"], d["pi"], d["pstar"], d["lam"], d["w"], d["XiN"], d["XiD"], d["Delta"], d["mu"], d["nu"], d["zeta"], d["vartheta"], d["varrho"]], device=dev, dtype=dt)
    U0 = u_from_dict(commitment_local_ss(params, 0))
    U1 = u_from_dict(commitment_local_ss(params, 1))
    # inverse square parameterization for positive vars
    def inv_param(u):
        u = u.clone()
        for i in [0,2,5,6,7]:
            u[i] = torch.sqrt(torch.clamp(u[i]- (1e-12 if i in [0,2,7] else 1e-14), min=1e-16))
        return u
    Z0 = pack(inv_param(U0), inv_param(U1))

    Z = _newton_solve(F, Z0, max_iter=max_iter, tol=tol, damping=damping)

    U0s, U1s = split(Z)

    # decode back
    def decode(U, vp_prev: float, rp_prev: float):
        c, pi, pstar, lam, w, XiN, XiD, Delta, mu, nu, zeta, vartheta, varrho = unpack(U)
        c = float((c**2 + 1e-12).cpu())
        pstar = float((pstar**2 + 1e-12).cpu())
        XiN = float((XiN**2 + 1e-14).cpu())
        XiD = float((XiD**2 + 1e-14).cpu())
        Delta = float((Delta**2 + 1e-12).cpu())
        return {
            "c": c, "pi": float(pi.cpu()), "pstar": pstar, "lam": float(lam.cpu()), "w": float(w.cpu()),
            "XiN": XiN, "XiD": XiD, "Delta": Delta, "mu": float(mu.cpu()), "nu": float(nu.cpu()), "zeta": float(zeta.cpu()),
            "vartheta": float(vartheta.cpu()), "varrho": float(varrho.cpu()),
            # Store *scaled* lagged co-states used by the Ramsey FOCs: vp_prev = E[ϑ_{t-1} c_{t-1}^γ | s_t], rp_prev = E[ϱ_{t-1} c_{t-1}^γ | s_t]
            "vartheta_prev": float(vp_prev),
            "varrho_prev": float(rp_prev),
        }

    # compute scaled co-states in each regime (vp_s = ϑ_s c_s^γ, rp_s = ϱ_s c_s^γ)
    c0 = float((U0s[0]**2 + 1e-12).cpu())
    c1 = float((U1s[0]**2 + 1e-12).cpu())
    vartheta0 = float(U0s[11].cpu()); vartheta1 = float(U1s[11].cpu())
    varrho0   = float(U0s[12].cpu()); varrho1   = float(U1s[12].cpu())
    vp0 = vartheta0 * (c0 ** float(gamma))
    vp1 = vartheta1 * (c1 ** float(gamma))
    rp0 = varrho0 * (c0 ** float(gamma))
    rp1 = varrho1 * (c1 ** float(gamma))

    # conditional expectations of lagged objects given current regime (consistent with Δ_{t-1} treatment)
    P_np = params.P.cpu().numpy()
    vp_prev_0 = P_np[0,0] * vp0 + P_np[1,0] * vp1
    vp_prev_1 = P_np[0,1] * vp0 + P_np[1,1] * vp1
    rp_prev_0 = P_np[0,0] * rp0 + P_np[1,0] * rp1
    rp_prev_1 = P_np[0,1] * rp0 + P_np[1,1] * rp1

    return CommitmentSSS(by_regime={
        0: decode(U0s, vp_prev=vp_prev_0, rp_prev=rp_prev_0),
        1: decode(U1s, vp_prev=vp_prev_1, rp_prev=rp_prev_1),
    })




@dataclass
class DiscretionSSS:
    by_regime: Dict[int, Dict[str, float]]

def solve_discretion_sss_switching(
    params: ModelParams,
    max_iter: int = 80,
    tol: float = 1e-12,
    damping: float = 1.0,
) -> DiscretionSSS:
    """
    Stochastic steady state (SSS) under discretion with regime switching (only Markov switching; no continuous shocks).

    We solve the Appendix A.2 system in each regime with expectations over next regime and with Delta_prev entering via
    E[Delta_{t-1} | s_t] = sum_{k} P[k, s_t] * Delta_k (same convention used in our commitment SSS).

    Unknowns per regime (11):
      [c, pi, pstar, lam, w, XiN, XiD, Delta, mu, rho, zeta]
    """
    from .model_common import State
    from .residuals_a2 import residuals_a2

    dev = params.device
    dt = torch.float64  # solve SSS in float64 for robustness

    # local params with float64 dtype
    import dataclasses as _dc
    _d = _dc.asdict(params)
    _d['dtype'] = dt
    params64 = ModelParams(**_d).to_torch()

    # constants (no continuous innovations)
    logA = torch.tensor(0.0, device=dev, dtype=dt)
    logg = torch.tensor(0.0, device=dev, dtype=dt)
    xi  = torch.tensor(0.0, device=dev, dtype=dt)

    P = params.P.to(device=dev, dtype=dt)  # [s_next, s]
    eps = params.eps
    theta = params.theta
    beta = params.beta

    def unpack(u: torch.Tensor):
        c, pi, pstar, lam, w, XiN, XiD, Delta, mu, rho, zeta = u
        return c, pi, pstar, lam, w, XiN, XiD, Delta, mu, rho, zeta

    def pack(c, pi, pstar, lam, w, XiN, XiD, Delta, mu, rho, zeta):
        return torch.stack([c, pi, pstar, lam, w, XiN, XiD, Delta, mu, rho, zeta])

    
    # --- Smooth parameterization for the SSS Newton solve ---
    # We solve over unconstrained variables z, and map them to levels u to avoid
    # clamp-induced singular Jacobians and to guarantee feasibility:
    #   c, pstar, lam, w, XiN, XiD, Delta > 0 via exp()
    #   pi bounded to keep (1+pi)>0 via tanh()
    PI_MAX = torch.tensor(0.2, device=dev, dtype=dt)  # +/-20% quarterly is safely wide

    def decode_z(z: torch.Tensor) -> torch.Tensor:
        zc, zpi, zp, zlam, zw, zN, zD, zDel, mu, rho, zeta = z
        c = torch.exp(zc)
        pi = PI_MAX * torch.tanh(zpi)
        pstar = torch.exp(zp)
        lam = torch.exp(zlam)
        w = torch.exp(zw)
        XiN = torch.exp(zN)
        XiD = torch.exp(zD)
        Delta = torch.exp(zDel)
        return pack(c, pi, pstar, lam, w, XiN, XiD, Delta, mu, rho, zeta)

    def encode_u(u: torch.Tensor) -> torch.Tensor:
        c, pi, pstar, lam, w, XiN, XiD, Delta, mu, rho, zeta = unpack(u)
        # keep pi strictly inside (-PI_MAX, PI_MAX) for atanh
        pi_scaled = (pi / PI_MAX).clamp(-0.999999, 0.999999)
        return pack(
            torch.log(c.clamp_min(1e-12)),
            torch.atanh(pi_scaled),
            torch.log(pstar.clamp_min(1e-12)),
            torch.log(lam.clamp_min(1e-12)),
            torch.log(w.clamp_min(1e-12)),
            torch.log(XiN.clamp_min(1e-12)),
            torch.log(XiD.clamp_min(1e-12)),
            torch.log(Delta.clamp_min(1e-12)),
            mu, rho, zeta
        )
    def F_val(lam, pi, XiD):
        return theta * beta * lam * (1.0 + pi).pow(eps - 1.0) * XiD

    def G_val(lam, pi, XiN):
        return theta * beta * lam * (1.0 + pi).pow(eps) * XiN

    def expectations(u0: torch.Tensor, u1: torch.Tensor):
        # values in each regime
        c0, pi0, pstar0, lam0, w0, XiN0, XiD0, D0, mu0, rho0, zeta0 = unpack(u0)
        c1, pi1, pstar1, lam1, w1, XiN1, XiD1, D1, mu1, rho1, zeta1 = unpack(u1)

        # F,G in next period by regime
        F0 = F_val(lam0, pi0, XiD0); F1 = F_val(lam1, pi1, XiD1)
        G0 = G_val(lam0, pi0, XiN0); G1 = G_val(lam1, pi1, XiN1)

        # theta*(1+pi)^eps*zeta in next period by regime
        TH0 = theta * (1.0 + pi0).pow(eps) * zeta0
        TH1 = theta * (1.0 + pi1).pow(eps) * zeta1

        # Xi recursions expectation terms (note Lambda depends on current regime)
        # For regime s: Et_XiN = sum_{sp} P[sp,s] * theta * Lambda(s->sp) * (1+pi_sp)^eps * XiN_sp
        # Lambda = beta * lam_sp / lam_s
        Et_XiN_0 = P[0,0] * (theta * (beta*lam0/lam0) * (1.0+pi0).pow(eps) * XiN0) + \
                  P[1,0] * (theta * (beta*lam1/lam0) * (1.0+pi1).pow(eps) * XiN1)
        Et_XiD_0 = P[0,0] * (theta * (beta*lam0/lam0) * (1.0+pi0).pow(eps-1.0) * XiD0) + \
                  P[1,0] * (theta * (beta*lam1/lam0) * (1.0+pi1).pow(eps-1.0) * XiD1)

        Et_XiN_1 = P[0,1] * (theta * (beta*lam0/lam1) * (1.0+pi0).pow(eps) * XiN0) + \
                  P[1,1] * (theta * (beta*lam1/lam1) * (1.0+pi1).pow(eps) * XiN1)
        Et_XiD_1 = P[0,1] * (theta * (beta*lam0/lam1) * (1.0+pi0).pow(eps-1.0) * XiD0) + \
                  P[1,1] * (theta * (beta*lam1/lam1) * (1.0+pi1).pow(eps-1.0) * XiD1)

        # Et_F, Et_G, Et_theta in each current regime
        Et_F_0 = P[0,0]*F0 + P[1,0]*F1
        Et_G_0 = P[0,0]*G0 + P[1,0]*G1
        Et_TH_0 = P[0,0]*TH0 + P[1,0]*TH1

        Et_F_1 = P[0,1]*F0 + P[1,1]*F1
        Et_G_1 = P[0,1]*G0 + P[1,1]*G1
        Et_TH_1 = P[0,1]*TH0 + P[1,1]*TH1

        return {
            0: {"Et_F": Et_F_0, "Et_G": Et_G_0, "Et_TH": Et_TH_0, "Et_XiN": Et_XiN_0, "Et_XiD": Et_XiD_0},
            1: {"Et_F": Et_F_1, "Et_G": Et_G_1, "Et_TH": Et_TH_1, "Et_XiN": Et_XiN_1, "Et_XiD": Et_XiD_1},
            "F_by_regime": (F0, F1),
            "G_by_regime": (G0, G1),
        }

    def delta_prev_exp(D0: torch.Tensor, D1: torch.Tensor):
        # same convention as commitment SSS (incoming transition weights)
        DP0 = P[0,0]*D0 + P[1,0]*D1
        DP1 = P[0,1]*D0 + P[1,1]*D1
        return DP0, DP1

    def implied_dF_dG_given_derivative_expectations(
        s: int,
        us: torch.Tensor,
        DP: torch.Tensor,
        *,
        Et_F_next: torch.Tensor,
        Et_G_next: torch.Tensor,
        Et_dF_dDelta_next: torch.Tensor,
        Et_dG_dDelta_next: torch.Tensor,
        Et_theta_zeta_pi_next: torch.Tensor,
        Et_XiN_next: torch.Tensor,
        Et_XiD_next: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Exact (no-approx) dF/dDeltaPrev and dG/dDeltaPrev via implicit differentiation.

        We differentiate the full Appendix A.2 residual system (including Delta FOC with the supplied
        Et_dF_dDelta_next, Et_dG_dDelta_next) w.r.t. the regime-specific Delta_prev parameter DP.

        NOTE: We return tensors with gradients stopped (detach) to keep the outer Newton system stable.
        The steady state itself is exact once the fixed-point conditions are satisfied.
        """
        us = us.clone().detach().to(device=dev, dtype=dt).requires_grad_(True)
        DP = DP.clone().detach().to(device=dev, dtype=dt).requires_grad_(True)

        st = State(
            Delta_prev=DP,
            logA=logA,
            loggtilde=logg,
            xi=xi,
            s=torch.tensor(float(s), device=dev, dtype=dt),
        )

        c, pi, pstar, lam, w, XiN, XiD, Delta, mu, rho, zeta = unpack(us)
        out = {"c": c, "pi": pi, "pstar": pstar, "lam": lam, "w": w,
               "XiN": XiN, "XiD": XiD, "Delta": Delta, "mu": mu, "rho": rho, "zeta": zeta}

        res = residuals_a2(
            params=params64,
            st=st,
            out=out,
            Et_F_next=Et_F_next,
            Et_G_next=Et_G_next,
            Et_dF_dDelta_next=Et_dF_dDelta_next,
            Et_dG_dDelta_next=Et_dG_dDelta_next,
            Et_theta_zeta_pi_next=Et_theta_zeta_pi_next,
            Et_XiN_next=Et_XiN_next,
            Et_XiD_next=Et_XiD_next,
        )
        keys = ["res_c_foc","res_pi_foc","res_pstar_foc","res_Delta_foc",
                "res_c_lam","res_labor","res_XiN_rec","res_XiD_rec",
                "res_pstar_def","res_calvo","res_Delta_law"]
        rvec = torch.stack([res[k] for k in keys])

        # Jacobian wrt us (11x11) and derivative wrt DP (11,)
        J = torch.autograd.functional.jacobian(lambda uu: torch.stack([
            residuals_a2(
                params=params64,
                st=st,
                out={"c": uu[0], "pi": uu[1], "pstar": uu[2], "lam": uu[3], "w": uu[4],
                     "XiN": uu[5], "XiD": uu[6], "Delta": uu[7], "mu": uu[8], "rho": uu[9], "zeta": uu[10]},
                Et_F_next=Et_F_next,
                Et_G_next=Et_G_next,
                Et_dF_dDelta_next=Et_dF_dDelta_next,
                Et_dG_dDelta_next=Et_dG_dDelta_next,
                Et_theta_zeta_pi_next=Et_theta_zeta_pi_next,
                Et_XiN_next=Et_XiN_next,
                Et_XiD_next=Et_XiD_next,
            )[k] for k in keys
        ]), us, create_graph=False)

        # d r / d DP
        b = torch.zeros((11,), device=dev, dtype=dt)
        for i in range(11):
            bi = torch.autograd.grad(rvec[i], DP, retain_graph=True, create_graph=False)[0]
            b[i] = bi

        dz = _robust_solve(J, -b)  # du/dDP

        # dF/dDP and dG/dDP via chain rule
        F = F_val(lam, pi, XiD)
        G = G_val(lam, pi, XiN)
        gF = torch.autograd.grad(F, us, retain_graph=True, create_graph=False)[0]
        gG = torch.autograd.grad(G, us, retain_graph=True, create_graph=False)[0]
        dF = (gF * dz).sum().detach()
        dG = (gG * dz).sum().detach()
        return dF, dG

    def residuals_full(Z: torch.Tensor) -> torch.Tensor:
            # Z holds unconstrained variables; map to levels to evaluate residuals.
            z0 = Z[:11]
            z1 = Z[11:22]
            dF0, dF1, dG0, dG1 = Z[22:26]
            u0 = decode_z(z0)
            u1 = decode_z(z1)
    
            # enforce (1+pi)>0 numerically to avoid invalid powers (should be satisfied by tanh bound)
            u0 = pack(u0[0], u0[1], u0[2], u0[3], u0[4], u0[5], u0[6], u0[7], u0[8], u0[9], u0[10])
            u1 = pack(u1[0], u1[1], u1[2], u1[3], u1[4], u1[5], u1[6], u1[7], u1[8], u1[9], u1[10])
    
            # Delta_prev expectations
            DP0, DP1 = delta_prev_exp(u0[7], u1[7])
    
            exps = expectations(u0, u1)
    
            # Derivatives for Delta FOC: treat (dF0,dF1,dG0,dG1) as unknowns and enforce
            # exact implicit-diff consistency below (no approximations).
    
            # Et_dF_next for current regime s uses next regime weights P[sp,s]
            Et_dF_0 = P[0,0]*dF0 + P[1,0]*dF1
            Et_dG_0 = P[0,0]*dG0 + P[1,0]*dG1
            Et_dF_1 = P[0,1]*dF0 + P[1,1]*dF1
            Et_dG_1 = P[0,1]*dG0 + P[1,1]*dG1
    
            # Evaluate residuals in each regime
            def res_regime(s:int, u:torch.Tensor, DP:torch.Tensor, Et_dF:torch.Tensor, Et_dG:torch.Tensor):
                st = State(
                    Delta_prev=DP,
                    logA=logA,
                    loggtilde=logg,
                    xi=xi,
                    s=torch.tensor(float(s), device=dev, dtype=dt),
                )
                c, pi, pstar, lam, w, XiN, XiD, Delta, mu, rho, zeta = unpack(u)
                out = {"c": c, "pi": pi, "pstar": pstar, "lam": lam, "w": w,
                       "XiN": XiN, "XiD": XiD, "Delta": Delta, "mu": mu, "rho": rho, "zeta": zeta}
                res = residuals_a2(
                    params=params64,
                    st=st,
                    out=out,
                    Et_F_next=exps[s]["Et_F"],
                    Et_G_next=exps[s]["Et_G"],
                    Et_dF_dDelta_next=Et_dF,
                    Et_dG_dDelta_next=Et_dG,
                    Et_theta_zeta_pi_next=exps[s]["Et_TH"],
                    Et_XiN_next=exps[s]["Et_XiN"],
                    Et_XiD_next=exps[s]["Et_XiD"],
                )
                keys = ["res_c_foc","res_pi_foc","res_pstar_foc","res_Delta_foc",
                        "res_c_lam","res_labor","res_XiN_rec","res_XiD_rec",
                        "res_pstar_def","res_calvo","res_Delta_law"]
                return torch.stack([res[k] for k in keys])
    
            r0 = res_regime(0, u0, DP0, Et_dF_0, Et_dG_0)
            r1 = res_regime(1, u1, DP1, Et_dF_1, Et_dG_1)
    
            # Implicit-diff consistency for derivatives (per regime)
            dF0_imp, dG0_imp = implied_dF_dG_given_derivative_expectations(
                0, u0, DP0,
                Et_F_next=exps[0]["Et_F"],
                Et_G_next=exps[0]["Et_G"],
                Et_dF_dDelta_next=Et_dF_0,
                Et_dG_dDelta_next=Et_dG_0,
                Et_theta_zeta_pi_next=exps[0]["Et_TH"],
                Et_XiN_next=exps[0]["Et_XiN"],
                Et_XiD_next=exps[0]["Et_XiD"],
            )
            dF1_imp, dG1_imp = implied_dF_dG_given_derivative_expectations(
                1, u1, DP1,
                Et_F_next=exps[1]["Et_F"],
                Et_G_next=exps[1]["Et_G"],
                Et_dF_dDelta_next=Et_dF_1,
                Et_dG_dDelta_next=Et_dG_1,
                Et_theta_zeta_pi_next=exps[1]["Et_TH"],
                Et_XiN_next=exps[1]["Et_XiN"],
                Et_XiD_next=exps[1]["Et_XiD"],
            )
    
            r_der = torch.stack([
                dF0 - dF0_imp,
                dF1 - dF1_imp,
                dG0 - dG0_imp,
                dG1 - dG1_imp,
            ])
            return torch.cat([r0, r1, r_der], dim=0)
    
    # Initial guess: close to efficient SS in each regime
    # Use flexible-price SSS consumption as baseline.
    flex = solve_flexprice_sss(params)
    c0 = torch.tensor(flex.by_regime[0]["c"], device=dev, dtype=dt)
    c1 = torch.tensor(flex.by_regime[1]["c"], device=dev, dtype=dt)
    pi0 = torch.tensor(0.0, device=dev, dtype=dt)
    pi1 = torch.tensor(0.0, device=dev, dtype=dt)
    p0 = torch.tensor(1.0, device=dev, dtype=dt)
    p1 = torch.tensor(1.0, device=dev, dtype=dt)
    lam0 = c0.pow(-params.gamma)
    lam1 = c1.pow(-params.gamma)

    # wages from labor FOC and h identity at Delta=1
    # At Delta=1, h = (c+g)*1/A, w = h^omega / lam
    gbar = torch.tensor(params.g_bar, device=dev, dtype=dt)
    h0 = (c0 + gbar)
    h1 = (c1 + gbar)
    w0 = h0.pow(params.omega) / lam0
    w1 = h1.pow(params.omega) / lam1

    # Xi guesses
    XiD0 = (c0 + gbar) / (1.0 - params.theta*params.beta)
    XiD1 = (c1 + gbar) / (1.0 - params.theta*params.beta)
    XiN0 = XiD0 * (params.eps/(params.eps-1.0))  # rough
    XiN1 = XiD1 * (params.eps/(params.eps-1.0))

    D0 = torch.tensor(1.0, device=dev, dtype=dt)
    D1 = torch.tensor(1.0, device=dev, dtype=dt)

    mu0 = torch.tensor(0.01, device=dev, dtype=dt)
    mu1 = torch.tensor(0.01, device=dev, dtype=dt)
    rho0 = torch.tensor(0.01, device=dev, dtype=dt)
    rho1 = torch.tensor(0.01, device=dev, dtype=dt)
    z0 = torch.tensor(0.01, device=dev, dtype=dt)
    z1 = torch.tensor(0.01, device=dev, dtype=dt)

    U0 = pack(c0, pi0, p0, lam0, w0, XiN0, XiD0, D0, mu0, rho0, z0)
    U1 = pack(c1, pi1, p1, lam1, w1, XiN1, XiD1, D1, mu1, rho1, z1)

    Z = torch.cat([encode_u(U0), encode_u(U1), torch.zeros(4, device=dev, dtype=dt)], dim=0).clone().detach().to(device=dev, dtype=dt)

    for it in range(max_iter):
        Z = Z.clone().detach().requires_grad_(True)
        r = residuals_full(Z)
        max_abs = float(r.abs().max().detach().cpu())
        if max_abs < tol:
            Z = Z.detach()
            break

        # Jacobian 26x26
        J = torch.zeros((26,26), device=dev, dtype=dt)
        for i in range(26):
            gi = torch.autograd.grad(r[i], Z, retain_graph=True)[0]
            J[i,:] = gi

        step = _robust_solve(J, -r.detach())

        # Backtracking line search to avoid NaNs / exp overflow in decode_z and to ensure progress.
        Z0 = Z.detach()
        r0_norm = float(r.detach().abs().max().cpu())
        alpha = float(damping)
        accepted = False
        for _ls in range(12):
            Z_try = (Z0 + alpha * step).clamp(-20.0, 20.0)
            r_try = residuals_full(Z_try)
            if torch.isfinite(r_try).all():
                r_try_norm = float(r_try.detach().abs().max().cpu())
                if r_try_norm <= r0_norm or alpha < 1e-4:
                    Z0 = Z_try.detach()
                    accepted = True
                    break
            alpha *= 0.5
        if not accepted:
            # fallback: take a tiny step
            Z0 = (Z0 + 1e-4 * step).clamp(-20.0, 20.0).detach()

        Z = Z0

    # Z packs: [z_reg0 (11), z_reg1 (11), dF0,dF1,dG0,dG1 (4)]
    u0 = decode_z(Z[:11]).detach().cpu()
    u1 = decode_z(Z[11:22]).detach().cpu()

    def decode(u: torch.Tensor) -> Dict[str, float]:
        c, pi, pstar, lam, w, XiN, XiD, Delta, mu, rho, zeta = [float(x) for x in u.tolist()]
        return {"c": c, "pi": pi, "pstar": pstar, "lam": lam, "w": w, "XiN": XiN, "XiD": XiD,
                "Delta": Delta, "mu": mu, "rho": rho, "zeta": zeta}

    return DiscretionSSS(by_regime={0: decode(u0), 1: decode(u1)})


def commitment_init_from_sss(params: ModelParams) -> Dict[int, Dict[str, float]]:
    """
    Return regime-specific initial lagged co-states for commitment.
    Keys 0 and 1 correspond to the current regime s_t used in the state vector.
    Each value contains:
        vartheta_prev:  ϑ_{t-1} * c_{t-1}^γ  (scaled lag co-state)
        varrho_prev:    ϱ_{t-1} * c_{t-1}^γ  (scaled lag co-state)
    """
    sss = solve_commitment_sss_switching(params).by_regime
    return {
        0: {"vartheta_prev": sss[0]["vartheta_prev"], "varrho_prev": sss[0]["varrho_prev"]},
        1: {"vartheta_prev": sss[1]["vartheta_prev"], "varrho_prev": sss[1]["varrho_prev"]},
    }
