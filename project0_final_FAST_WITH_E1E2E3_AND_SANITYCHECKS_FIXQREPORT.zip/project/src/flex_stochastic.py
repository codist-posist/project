"""Stochastic flex-price diagnostics for Project1 (Veronica critique).

We compute a regime-conditional "natural" nominal rate r*_s implied by the Euler equation
under flex prices (no price stickiness), using simulated consumption growth:

    1 + r*_s = ( beta * E[(c_{t+1}/c_t)^(-gamma) | s_t=s] )^{-1}

This is a diagnostic object (not used inside DEQN training) meant to test whether
regime-dependent uncertainty can flip the sign of Δr*.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np
import torch

from .config import ModelParams
from .markov import draw_next_regime
from .steady_states import solve_flexprice_sss


@dataclass
class RStarResult:
    rstar_by_regime: Dict[int, float]
    delta_rstar: float
    samples_by_regime: Dict[int, int]


def _simulate_markov_path(params: ModelParams, T: int, s0: int, rng: np.random.Generator) -> np.ndarray:
    """Simulate regimes with the project's transition matrix convention P[s_next, s]."""
    P = params.P.detach().cpu().numpy()
    s = np.empty(T + 1, dtype=np.int64)
    s[0] = int(s0)
    for t in range(T):
        u = rng.random()
        # s_next=0 with prob P[0, s_t]
        s[t + 1] = 0 if u < P[0, s[t]] else 1
    return s


def _flex_consumption_one_period(params: ModelParams, logA: float, loggtilde: float, xi: float, s: int) -> float:
    """Exact one-period flex allocation given exogenous state.

    Under flexible prices we have (Δ=1, π=0, p* = 1). Using the project's sticky-price
    block identities/recursions with θ=0:

        XiD = y
        XiN = y * w * (1+τ) / A
        p* = M * XiN/XiD = M * w * (1+τ) / A = 1
      => w = A / (M * (1+τ))

    Intratemporal condition and production/resource constraints:

        h^ω = w * c^{-γ}
        y = c + g
        y = A*h  (since Δ=1)
      => h = (c+g)/A

    Combine:
        ((c+g)/A)^ω = (A / (M*(1+τ))) * c^{-γ}

    We solve this scalar equation for c>0 by Newton with safeguards.
    """
    A = float(np.exp(logA))
    g = float(np.exp(loggtilde)) * params.g_bar
    eta = 0.0 if int(s) == 0 else float(params.eta_bar)
    one_plus_tau = float(1.0 - params.tau_bar + xi + eta)
    M = float(params.M)

    # Numerical safety: clamp extremely small/negative wedges
    one_plus_tau = max(1e-8, one_plus_tau)
    A = max(1e-8, A)

    omega = float(params.omega)
    gamma = float(params.gamma)

    # Use SSS consumption as a good initial guess
    flex = solve_flexprice_sss(params)
    c0 = float(flex.by_regime[0]["c"])
    c1 = float(flex.by_regime[1]["c"])
    c = c0 if int(s) == 0 else c1
    c = max(1e-10, c)

    # Define f(c)=0
    # left = ((c+g)/A)^ω
    # right = A/(M*(1+τ)) * c^{-γ}
    K = A / (M * one_plus_tau)

    for _ in range(50):
        cp = c + g
        # Ensure positivity
        if cp <= 1e-12:
            c = max(1e-10, -g + 1e-8)
            cp = c + g
        left = (cp / A) ** omega
        right = K * (c ** (-gamma))
        f = left - right

        # Derivative: d/dc left = ω*(cp/A)^{ω-1}*(1/A)
        dleft = omega * (cp / A) ** (omega - 1.0) * (1.0 / A)
        # d/dc right = K * (-γ) * c^{-γ-1}
        dright = K * (-gamma) * (c ** (-gamma - 1.0))
        df = dleft - dright

        step = f / df
        c_new = c - step
        # Safeguards
        if not np.isfinite(c_new) or c_new <= 0:
            c_new = max(1e-10, 0.5 * c)
        if abs(c_new - c) < 1e-12:
            c = c_new
            break
        c = c_new

    return float(max(1e-12, c))


def compute_rstar_by_regime(
    params: ModelParams,
    *,
    T: int = 120_000,
    burn_in: int = 20_000,
    s0: int = 0,
    seed: int = 0,
) -> RStarResult:
    """Compute regime-conditional r*_s via simulated consumption growth (E1)."""
    assert T > burn_in + 10
    rng = np.random.default_rng(seed)

    # Simulate regimes and exogenous processes
    s_path = _simulate_markov_path(params, T=T, s0=s0, rng=rng)

    logA = np.zeros(T + 1)
    logg = np.zeros(T + 1)  # log(gtilde)
    xi = np.zeros(T + 1)

    for t in range(T):
        s_t = int(s_path[t])
        # regime-dependent sigmas (current regime)
        mA = 1.0 + (params.sigma_A_bad_mult - 1.0) * s_t
        mg = 1.0 + (params.sigma_g_bad_mult - 1.0) * s_t
        mt = 1.0 + (params.sigma_tau_bad_mult - 1.0) * s_t
        sigA = params.sigma_A * mA
        sigg = params.sigma_g * mg
        sigt = params.sigma_tau * mt

        epsA = rng.standard_normal()
        epsg = rng.standard_normal()
        epst = rng.standard_normal()

        driftA = (1.0 - params.rho_A) * (-(sigA**2) / (2.0 * (1.0 - params.rho_A**2)))
        driftg = (1.0 - params.rho_g) * (-(sigg**2) / (2.0 * (1.0 - params.rho_g**2)))

        logA[t + 1] = driftA + params.rho_A * logA[t] + sigA * epsA
        logg[t + 1] = driftg + params.rho_g * logg[t] + sigg * epsg
        xi[t + 1] = params.rho_tau * xi[t] + sigt * epst

    # Consumption proxy and IMRS
    c = np.empty(T + 1)
    for t in range(T + 1):
        c[t] = _flex_consumption_one_period(params, logA[t], logg[t], xi[t], int(s_path[t]))

    cg = c[1:] / c[:-1]
    imrs = cg ** (-params.gamma)

    # Condition on s_t (not s_{t+1})
    s_t = s_path[:-1]
    mask0 = (s_t == 0)
    mask1 = (s_t == 1)

    def rstar_from_mask(mask):
        vals = imrs[mask][burn_in:]
        if vals.size == 0:
            return float("nan"), 0
        Et = float(vals.mean())
        r = (1.0 / (params.beta * Et)) - 1.0
        return r, int(vals.size)

    r0, n0 = rstar_from_mask(mask0)
    r1, n1 = rstar_from_mask(mask1)

    return RStarResult(
        rstar_by_regime={0: r0, 1: r1},
        delta_rstar=r1 - r0,
        samples_by_regime={0: n0, 1: n1},
    )
