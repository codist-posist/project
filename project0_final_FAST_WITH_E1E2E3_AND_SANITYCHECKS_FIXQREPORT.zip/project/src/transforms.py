from __future__ import annotations
from typing import Dict
import torch
import torch.nn.functional as F

def positive(x: torch.Tensor, floor: float = 1e-10) -> torch.Tensor:
    return F.softplus(x) + floor

def decode_outputs(policy: str, raw: torch.Tensor, floors: Dict[str, float]) -> Dict[str, torch.Tensor]:
    if policy in ["taylor", "mod_taylor"]:
        names = ["c","pi","pstar","lam","w","XiN","XiD","Delta"]
    elif policy == "discretion":
        names = ["c","pi","pstar","lam","w","XiN","XiD","Delta","mu","rho","zeta"]
    elif policy == "commitment":
        names = ["c","pi","pstar","lam","w","XiN","XiD","Delta","mu","nu","zeta","vartheta","varrho"]
    else:
        raise ValueError(policy)

    out = {n: raw[..., i] for i, n in enumerate(names)}
    # Make inflation safe: parameterize 1+pi > 0 to avoid invalid powers in Calvo terms
    _raw_pi = out["pi"]
    out["one_plus_pi"] = positive(_raw_pi, floors.get("one_plus_pi", floors.get("pi", 1e-6)))
    out["pi"] = out["one_plus_pi"] - 1.0
    out["c"]     = positive(out["c"], floors.get("c", 1e-10))
    out["Delta"] = positive(out["Delta"], floors.get("Delta", 1e-10))
    out["pstar"] = positive(out["pstar"], floors.get("pstar", 1e-10))
    out["lam"]   = positive(out["lam"], floors.get("lam", 1e-12))
    out["w"]     = positive(out["w"], floors.get("w", 1e-12))
    out["XiN"]   = positive(out["XiN"], floors.get("XiN", 1e-14))
    out["XiD"]   = positive(out["XiD"], floors.get("XiD", 1e-14))
    return out