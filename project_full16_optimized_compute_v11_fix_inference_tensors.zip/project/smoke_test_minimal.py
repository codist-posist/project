
import torch
from src.config import ModelParams
from src.deqn import PolicyNetwork, Trainer

def run(policy: str):
    params = ModelParams()
    net = PolicyNetwork(policy=policy, hidden=64, depth=2)
    trainer = Trainer(params=params, net=net, policy=policy)  # use defaults
    x = trainer.simulate_initial_state(8, commitment_sss=None)
    # Must run with grad enabled for discretion/commitment
    with torch.enable_grad():
        resid = trainer._residuals(x)
    assert torch.isfinite(resid).all(), f"Non-finite residuals for {policy}"
    print("ok", policy, tuple(resid.shape))

if __name__ == "__main__":
    for pol in ["taylor","mod_taylor","discretion","commitment"]:
        run(pol)
