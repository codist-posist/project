from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import torch

from .config import ModelParams, PolicyName
from .model_common import unpack_state, shock_laws_of_motion
from .transforms import decode_outputs


@dataclass
class PolicySSS:
    """Stochastic steady state computed as a fixed point of a (trained) policy."""

    by_regime: Dict[int, Dict[str, float]]


def _uncond_mean_log_ar1(rho: float, sigma: float) -> float:
    """Mean of log state under the drift-corrected AR(1) used in shock_laws_of_motion."""
    # With drift correction in model_common.shock_laws_of_motion, the stationary mean is:
    #   E[log x] = -(sigma^2)/(2*(1-rho^2))
    # (when innovations are N(0,1)).
    if abs(1.0 - rho) < 1e-12:
        return 0.0
    return float(-(sigma**2) / (2.0 * (1.0 - rho**2)))



@torch.no_grad()
def simple_policy_sss_from_policy(
    params: ModelParams,
    net: torch.nn.Module,
    *,
    policy: PolicyName,
    regime: int,
    max_iter: int = 10_000,
    tol: float = 1e-12,
    damping: float = 0.25,
    floors: Optional[Dict[str, float]] = None,
) -> Dict[str, float]:
    """Fixed-point SSS for policies whose state is x=(Delta_{t-1}, logA_t, logg_t, xi_t, s_t).

    This covers: taylor, mod_taylor, discretion.

    We hold the regime fixed and set innovations to zero. Continuous shocks are set to their
    drift-corrected stationary means (via _uncond_mean_log_ar1) and then kept fixed by the
    deterministic AR(1) transition with zero innovations.
    """
    if floors is None:
        floors = {"c": 1e-8, "Delta": 1e-10, "pstar": 1e-10}

    dev, dt = params.device, params.dtype
    s = int(regime)

    logA0 = _uncond_mean_log_ar1(float(params.rho_A), float(params.sigma_A))
    logg0 = _uncond_mean_log_ar1(float(params.rho_g), float(params.sigma_g))
    xi0 = 0.0

    x = torch.tensor([1.0, logA0, logg0, xi0, float(s)], device=dev, dtype=dt).view(1, -1)

    eps0 = torch.zeros(1, device=dev, dtype=dt)
    s_fixed = torch.full((1,), s, device=dev, dtype=torch.long)

    for _ in range(int(max_iter)):
        out = decode_outputs(policy, net(x), floors=floors)
        st = unpack_state(x, policy)

        logA_n, logg_n, xi_n, s_n = shock_laws_of_motion(params, st, eps0, eps0, eps0, s_fixed)
        x_next = torch.stack(
            [out["Delta"], logA_n.view(-1), logg_n.view(-1), xi_n.view(-1), s_n.to(dt)],
            dim=-1,
        )

        diff = (x_next - x).abs().max().item()
        x = (1.0 - damping) * x + damping * x_next
        if diff < tol:
            break

    out = decode_outputs(policy, net(x), floors=floors)
    res = {
        "c": float(out["c"].item()),
        "pi": float(out["pi"].item()),
        "pstar": float(out["pstar"].item()),
        "lam": float(out["lam"].item()),
        "w": float(out["w"].item()),
        "XiN": float(out["XiN"].item()),
        "XiD": float(out["XiD"].item()),
        "Delta": float(out["Delta"].item()),
        "mu": float(out.get("mu", torch.tensor(0.0, device=dev, dtype=dt)).item()),
        "nu": float(out.get("nu", torch.tensor(0.0, device=dev, dtype=dt)).item()),
        "zeta": float(out.get("zeta", torch.tensor(0.0, device=dev, dtype=dt)).item()),
        "logA": float(x[0, 1].item()),
        "loggtilde": float(x[0, 2].item()),
        "xi": float(x[0, 3].item()),
    }
    return res


@torch.no_grad()
def discretion_sss_from_policy(
    params: ModelParams,
    net: torch.nn.Module,
    *,
    regime: int,
    max_iter: int = 10_000,
    tol: float = 1e-12,
    damping: float = 0.25,
    floors: Optional[Dict[str, float]] = None,
) -> Dict[str, float]:
    """Compute discretion SSS for a fixed regime as a fixed point of a trained policy."""
    return simple_policy_sss_from_policy(
        params,
        net,
        policy="discretion",
        regime=regime,
        max_iter=max_iter,
        tol=tol,
        damping=damping,
        floors=floors,
    )



@torch.no_grad()
@torch.no_grad()
def taylor_sss_from_policy(
    params: ModelParams,
    net: torch.nn.Module,
    *,
    regime: int,
    max_iter: int = 10_000,
    tol: float = 1e-12,
    damping: float = 0.25,
    floors: Optional[Dict[str, float]] = None,
) -> Dict[str, float]:
    """Taylor-rule SSS for a fixed regime as a fixed point of a trained policy."""
    return simple_policy_sss_from_policy(
        params,
        net,
        policy="taylor",
        regime=regime,
        max_iter=max_iter,
        tol=tol,
        damping=damping,
        floors=floors,
    )


@torch.no_grad()
def mod_taylor_sss_from_policy(
    params: ModelParams,
    net: torch.nn.Module,
    *,
    regime: int,
    max_iter: int = 10_000,
    tol: float = 1e-12,
    damping: float = 0.25,
    floors: Optional[Dict[str, float]] = None,
) -> Dict[str, float]:
    """Modified Taylor-rule SSS for a fixed regime as a fixed point of a trained policy."""
    return simple_policy_sss_from_policy(
        params,
        net,
        policy="mod_taylor",
        regime=regime,
        max_iter=max_iter,
        tol=tol,
        damping=damping,
        floors=floors,
    )


def discretion_sss_by_regime_from_policy(
    params: ModelParams,
    net: torch.nn.Module,
    *,
    max_iter: int = 10_000,
    tol: float = 1e-12,
    damping: float = 0.25,
    floors: Optional[Dict[str, float]] = None,
) -> PolicySSS:
    nS = int(getattr(params, "n_regimes", 2))
    return PolicySSS(
        by_regime={
            s: discretion_sss_from_policy(params, net, regime=s, max_iter=max_iter, tol=tol, damping=damping, floors=floors)
            for s in range(nS)
        }
    )



@torch.no_grad()
def taylor_sss_by_regime_from_policy(
    params: ModelParams,
    net: torch.nn.Module,
    *,
    max_iter: int = 10_000,
    tol: float = 1e-12,
    damping: float = 0.25,
    floors: Optional[Dict[str, float]] = None,
) -> PolicySSS:
    nS = int(getattr(params, "n_regimes", 2))
    return PolicySSS(
        by_regime={
            s: taylor_sss_from_policy(params, net, regime=s, max_iter=max_iter, tol=tol, damping=damping, floors=floors)
            for s in range(nS)
        }
    )


@torch.no_grad()
def mod_taylor_sss_by_regime_from_policy(
    params: ModelParams,
    net: torch.nn.Module,
    *,
    max_iter: int = 10_000,
    tol: float = 1e-12,
    damping: float = 0.25,
    floors: Optional[Dict[str, float]] = None,
) -> PolicySSS:
    nS = int(getattr(params, "n_regimes", 2))
    return PolicySSS(
        by_regime={
            s: mod_taylor_sss_from_policy(params, net, regime=s, max_iter=max_iter, tol=tol, damping=damping, floors=floors)
            for s in range(nS)
        }
    )




@torch.no_grad()
def commitment_sss_from_policy(
    params: ModelParams,
    net: torch.nn.Module,
    *,
    regime: int,
    max_iter: int = 10_000,
    tol: float = 1e-12,
    damping: float = 0.25,
    floors: Optional[Dict[str, float]] = None,
) -> Dict[str, float]:
    """
    Compute the commitment SSS for a FIXED regime as the fixed point of the trained policy.

    This matches the paper's definition used in their transition figures: set innovations to zero,
    hold the regime fixed, and solve for a fixed point under the optimal policy (timeless).

    State for commitment is:
        x = (Delta_{t-1}, logA_t, logg_t, xi_t, s_t, vp_t, rp_t)
    where vp_t = vartheta_{t-1} * c_{t-1}^gamma and rp_t = varrho_{t-1} * c_{t-1}^gamma.
    """
    if floors is None:
        floors = {"c": 1e-8, "Delta": 1e-10, "pstar": 1e-10}

    dev, dt = params.device, params.dtype
    s = int(regime)

    # Start from a reasonable unconditional-mean point for continuous shocks.
    logA0 = _uncond_mean_log_ar1(float(params.rho_A), float(params.sigma_A))
    logg0 = _uncond_mean_log_ar1(float(params.rho_g), float(params.sigma_g))
    xi0 = 0.0

    # Initialize at near-flex steady objects: Delta=1, multipliers=0.
    x = torch.tensor(
        [1.0, logA0, logg0, xi0, float(s), 0.0, 0.0],
        device=dev,
        dtype=dt,
    ).view(1, -1)

    eps0 = torch.zeros(1, device=dev, dtype=dt)
    s_fixed = torch.full((1,), s, device=dev, dtype=torch.long)

    for _ in range(int(max_iter)):
        out = decode_outputs("commitment", net(x), floors=floors)
        st = unpack_state(x, "commitment")

        # Deterministic transition: zero innovations + fixed regime
        logA_n, logg_n, xi_n, s_n = shock_laws_of_motion(params, st, eps0, eps0, eps0, s_fixed)
        vp_n = out["vartheta"] * out["c"].pow(params.gamma)
        rp_n = out["varrho"] * out["c"].pow(params.gamma)
        x_next = torch.stack(
            [out["Delta"], logA_n.view(-1), logg_n.view(-1), xi_n.view(-1), s_n.to(dt), vp_n.view(-1), rp_n.view(-1)],
            dim=-1,
        )

        diff = (x_next - x).abs().max().item()
        x = (1.0 - damping) * x + damping * x_next
        if diff < tol:
            break

    # Report at the fixed point
    out = decode_outputs("commitment", net(x), floors=floors)
    return {
        "c": float(out["c"].item()),
        "pi": float(out["pi"].item()),
        "pstar": float(out["pstar"].item()),
        "lam": float(out["lam"].item()),
        "w": float(out["w"].item()),
        "XiN": float(out["XiN"].item()),
        "XiD": float(out["XiD"].item()),
        "Delta": float(out["Delta"].item()),
        "mu": float(out["mu"].item()),
        "nu": float(out["nu"].item()),
        "zeta": float(out["zeta"].item()),
        "vartheta": float(out["vartheta"].item()),
        "varrho": float(out["varrho"].item()),
        # Exogenous-state components at the fixed point (useful for constructing x0)
        "logA": float(x[0, 1].item()),
        "loggtilde": float(x[0, 2].item()),
        "xi": float(x[0, 3].item()),
        # store lagged co-states in the same representation used in the commitment state
        "vartheta_prev": float(x[0, 5].item()),
        "varrho_prev": float(x[0, 6].item()),
    }


@torch.no_grad()
def commitment_sss_by_regime_from_policy(
    params: ModelParams,
    net: torch.nn.Module,
    *,
    max_iter: int = 10_000,
    tol: float = 1e-12,
    damping: float = 0.25,
    floors: Optional[Dict[str, float]] = None,
) -> PolicySSS:
    nS = int(getattr(params, "n_regimes", 2))
    return PolicySSS(
        by_regime={
            s: commitment_sss_from_policy(params, net, regime=s, max_iter=max_iter, tol=tol, damping=damping, floors=floors)
            for s in range(nS)
        }
    )
